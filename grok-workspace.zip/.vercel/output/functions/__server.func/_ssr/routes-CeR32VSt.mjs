import { i as __toESM } from "../_runtime.mjs";
import { u as require_react } from "../_libs/@floating-ui/react-dom+[...].mjs";
import { o as require_jsx_runtime } from "../_libs/@radix-ui/react-collection+[...].mjs";
import { A as Eye, C as Magnet, D as FolderOpen, E as Hand, F as Blend, M as Eraser, N as Download, O as Film, P as Brush, S as Move, T as ImagePlus, _ as Play, a as Vibrate, b as Pause, d as SlidersHorizontal, f as Scan, g as Plus, h as Redo2, i as Waves, j as EyeOff, k as FileJson, l as Trash2, m as RotateCcw, n as ZoomOut, o as Upload, p as RotateCw, r as X, s as Undo2, t as ZoomIn, u as Snowflake, v as Pentagon, w as Lasso, x as PaintBucket, y as PenLine } from "../_libs/lucide-react.mjs";
import { i as SliderTrack, n as SliderRange, r as SliderThumb, t as Slider } from "../_libs/@radix-ui/react-slider+[...].mjs";
import { a as TooltipTrigger, i as TooltipProvider, n as TooltipContent, r as TooltipPortal, t as Tooltip } from "../_libs/@radix-ui/react-tooltip+[...].mjs";
import { n as toast, t as Toaster } from "../_libs/sonner.mjs";
import { t as clsx } from "../_libs/clsx.mjs";
import { t as twMerge } from "../_libs/tailwind-merge.mjs";
//#region node_modules/.nitro/vite/services/ssr/assets/routes-CeR32VSt.js
var import_react = /* @__PURE__ */ __toESM(require_react());
var import_jsx_runtime = require_jsx_runtime();
var gummy_default = "/assets/gummy-DecArBCs.jpg";
function cn(...inputs) {
	return twMerge(clsx(inputs));
}
function lerp(a, b, t) {
	return a + (b - a) * t;
}
function clamp(v, min, max) {
	return Math.max(min, Math.min(max, v));
}
function smoothstep(edge0, edge1, x) {
	const t = clamp((x - edge0) / (edge1 - edge0), 0, 1);
	return t * t * (3 - 2 * t);
}
function hexToRgb(hex) {
	const h = hex.replace("#", "");
	const n = Number.parseInt(h.length === 3 ? h.replace(/./g, (c) => c + c) : h, 16);
	return [
		n >> 16 & 255,
		n >> 8 & 255,
		n & 255
	];
}
function blurAxis(src, dst, w, h, radius, vertical) {
	const r = Math.max(0, radius | 0);
	const win = r * 2 + 1;
	if (r === 0) {
		dst.set(src);
		return;
	}
	if (!vertical) {
		for (let y = 0; y < h; y++) {
			const row = y * w;
			let sum = 0;
			for (let k = -r; k <= r; k++) sum += src[row + clamp(k, 0, w - 1)];
			for (let x = 0; x < w; x++) {
				dst[row + x] = sum / win | 0;
				const remove = src[row + clamp(x - r, 0, w - 1)];
				const add = src[row + clamp(x + r + 1, 0, w - 1)];
				sum += add - remove;
			}
		}
		return;
	}
	for (let x = 0; x < w; x++) {
		let sum = 0;
		for (let k = -r; k <= r; k++) sum += src[clamp(k, 0, h - 1) * w + x];
		for (let y = 0; y < h; y++) {
			dst[y * w + x] = sum / win | 0;
			const remove = src[clamp(y - r, 0, h - 1) * w + x];
			const add = src[clamp(y + r + 1, 0, h - 1) * w + x];
			sum += add - remove;
		}
	}
}
function boxBlur(src, w, h, radius, passes = 2) {
	if (radius < 1) return src.slice();
	const a = new Uint8Array(src.length);
	const b = new Uint8Array(src.length);
	let cur = src;
	for (let p = 0; p < passes; p++) {
		blurAxis(cur, a, w, h, radius, false);
		blurAxis(a, b, w, h, radius, true);
		cur = b;
	}
	return cur === src ? src.slice() : cur.slice();
}
function stampBrush(mask, w, h, cx, cy, radius, strength, softness, add, hard) {
	const r = Math.max(.75, radius);
	const x0 = Math.max(0, Math.floor(cx - r));
	const y0 = Math.max(0, Math.floor(cy - r));
	const x1 = Math.min(w - 1, Math.ceil(cx + r));
	const y1 = Math.min(h - 1, Math.ceil(cy + r));
	const inner = r * (1 - (hard ? Math.min(.4, softness * .4) : clamp(.2 + softness * .8, 0, 1)));
	const span = Math.max(.001, r - inner);
	for (let y = y0; y <= y1; y++) {
		const dy = y + .5 - cy;
		for (let x = x0; x <= x1; x++) {
			const dx = x + .5 - cx;
			const d = Math.hypot(dx, dy);
			if (d > r) continue;
			let a = 1;
			if (d > inner) {
				const s = 1 - (d - inner) / span;
				a = s * s * (3 - 2 * s);
			}
			a *= strength;
			const i = y * w + x;
			const prev = mask[i];
			mask[i] = add ? Math.min(255, prev + a * (255 - prev)) : Math.max(0, prev * (1 - a));
		}
	}
}
function fillPolygon(points, w, h) {
	const temp = new Uint8Array(w * h);
	if (points.length < 3) return temp;
	for (let y = 0; y < h; y++) {
		const nodes = [];
		for (let i = 0, j = points.length - 1; i < points.length; j = i++) {
			const a = points[j];
			const b = points[i];
			if (a.y < y && b.y >= y || b.y < y && a.y >= y) {
				const t = (y - a.y) / (b.y - a.y);
				nodes.push(a.x + (b.x - a.x) * t);
			}
		}
		nodes.sort((p, q) => p - q);
		for (let k = 0; k + 1 < nodes.length; k += 2) {
			let x0 = Math.ceil(nodes[k]);
			let x1 = Math.floor(nodes[k + 1]);
			if (x1 < x0) continue;
			x0 = clamp(x0, 0, w - 1);
			x1 = clamp(x1, 0, w - 1);
			const row = y * w;
			for (let x = x0; x <= x1; x++) temp[row + x] = 255;
		}
	}
	return temp;
}
function compositeMax(mask, src, add, strength) {
	const gain = clamp(strength, 0, 1);
	for (let i = 0; i < mask.length; i++) {
		const a = src[i] / 255 * gain;
		if (a <= 0) continue;
		const prev = mask[i];
		mask[i] = add ? Math.min(255, Math.max(prev, src[i] * gain)) : Math.max(0, prev * (1 - a));
	}
}
function floodFill(pixels, w, h, sx, sy, tolerance) {
	const temp = new Uint8Array(w * h);
	const x = clamp(sx | 0, 0, w - 1);
	const start = clamp(sy | 0, 0, h - 1) * w + x;
	const tr = pixels[start * 4];
	const tg = pixels[start * 4 + 1];
	const tb = pixels[start * 4 + 2];
	const tol = tolerance * tolerance;
	const seen = new Uint8Array(w * h);
	const stack = [start];
	while (stack.length) {
		const p = stack.pop();
		if (seen[p]) continue;
		seen[p] = 1;
		const r = pixels[p * 4] - tr;
		const g = pixels[p * 4 + 1] - tg;
		const b = pixels[p * 4 + 2] - tb;
		if (r * r + g * g + b * b > tol) continue;
		temp[p] = 255;
		const px = p % w;
		const py = p / w | 0;
		if (px > 0) stack.push(p - 1);
		if (px < w - 1) stack.push(p + 1);
		if (py > 0) stack.push(p - w);
		if (py < h - 1) stack.push(p + w);
	}
	return temp;
}
function smoothBrush(mask, w, h, cx, cy, radius, strength) {
	const r = Math.max(1, radius);
	const x0 = Math.max(0, Math.floor(cx - r));
	const y0 = Math.max(0, Math.floor(cy - r));
	const x1 = Math.min(w - 1, Math.ceil(cx + r));
	const y1 = Math.min(h - 1, Math.ceil(cy + r));
	const src = mask.slice();
	const n = 2;
	for (let y = y0; y <= y1; y++) for (let x = x0; x <= x1; x++) {
		const dx = x + .5 - cx;
		const dy = y + .5 - cy;
		const d = Math.hypot(dx, dy);
		if (d > r) continue;
		let sum = 0;
		let count = 0;
		const iy0 = Math.max(0, y - n);
		const iy1 = Math.min(h - 1, y + n);
		const ix0 = Math.max(0, x - n);
		const ix1 = Math.min(w - 1, x + n);
		for (let yy = iy0; yy <= iy1; yy++) {
			const row = yy * w;
			for (let xx = ix0; xx <= ix1; xx++) {
				sum += src[row + xx];
				count++;
			}
		}
		const avg = sum / count;
		const fall = 1 - d / r;
		const t = fall * fall * strength;
		const i = y * w + x;
		mask[i] = mask[i] * (1 - t) + avg * t;
	}
}
function maskHasInk(mask) {
	for (let i = 0; i < mask.length; i += 13) if (mask[i] > 12) return true;
	return false;
}
function derive(params, unit) {
	const e = params.elasticity / 100;
	const mass = lerp(.45, 2.8, params.mass / 100);
	return {
		anchor: lerp(8, 160, params.recovery / 100) * lerp(.82, 1.18, e),
		stiff: lerp(36, 480, params.stiffness / 100),
		shear: lerp(20, 300, params.stiffness / 100),
		damp: lerp(1.7, 16, params.damping / 100) * lerp(1.28, .6, e),
		gravity: lerp(0, 1500, params.gravity / 100) * unit,
		deform: lerp(.12, 1.42, params.deform / 100),
		maxDisp: lerp(.03, .5, params.maxDisp / 100) * unit * 1e3,
		grab: 148,
		bounce: lerp(90, 1500, params.bounce / 100) * unit,
		mass
	};
}
var SoftBody = class {
	cols;
	rows;
	imgW;
	imgH;
	count;
	x;
	y;
	vx;
	vy;
	rx;
	ry;
	w = /* @__PURE__ */ new Float32Array(0);
	region;
	frozen;
	invMass;
	border;
	si;
	sj;
	srest;
	skind;
	springCount;
	ax;
	ay;
	grabFall;
	params = [];
	derived = [];
	grabbing = false;
	grabRegion = -1;
	grabDX = 0;
	grabDY = 0;
	constructor(cols, rows, imgW, imgH) {
		this.cols = cols;
		this.rows = rows;
		this.imgW = imgW;
		this.imgH = imgH;
		const nx = cols + 1;
		const ny = rows + 1;
		const n = nx * ny;
		this.count = n;
		this.x = new Float32Array(n);
		this.y = new Float32Array(n);
		this.vx = new Float32Array(n);
		this.vy = new Float32Array(n);
		this.rx = new Float32Array(n);
		this.ry = new Float32Array(n);
		this.w = new Float32Array(n);
		this.region = new Int16Array(n);
		this.region.fill(-1);
		this.frozen = new Uint8Array(n);
		this.invMass = new Float32Array(n);
		this.border = new Uint8Array(n);
		this.ax = new Float32Array(n);
		this.ay = new Float32Array(n);
		this.grabFall = new Float32Array(n);
		for (let r = 0; r < ny; r++) for (let c = 0; c < nx; c++) {
			const i = r * nx + c;
			const px = c / cols * imgW;
			const py = r / rows * imgH;
			this.rx[i] = px;
			this.ry[i] = py;
			this.x[i] = px;
			this.y[i] = py;
			this.border[i] = c === 0 || r === 0 || c === cols || r === rows ? 1 : 0;
		}
		const pairs = [];
		const kinds = [];
		const add = (a, b, shear) => {
			pairs.push(a, b);
			kinds.push(shear);
		};
		for (let r = 0; r < ny; r++) for (let c = 0; c < nx; c++) {
			const i = r * nx + c;
			if (c + 1 < nx) add(i, i + 1, 0);
			if (r + 1 < ny) add(i, i + nx, 0);
			if (c + 1 < nx && r + 1 < ny) {
				add(i, i + nx + 1, 1);
				add(i + 1, i + nx, 1);
			}
		}
		const m = kinds.length;
		this.springCount = m;
		this.si = new Uint16Array(m);
		this.sj = new Uint16Array(m);
		this.srest = new Float32Array(m);
		this.skind = new Uint8Array(m);
		for (let s = 0; s < m; s++) {
			const a = pairs[s * 2];
			const b = pairs[s * 2 + 1];
			this.si[s] = a;
			this.sj[s] = b;
			this.skind[s] = kinds[s];
			const dx = this.rx[a] - this.rx[b];
			const dy = this.ry[a] - this.ry[b];
			this.srest[s] = Math.hypot(dx, dy) || 1;
		}
	}
	setMaps(weight, region, frozen, params) {
		this.w.set(weight);
		this.region.set(region);
		this.frozen.set(frozen);
		this.params = params;
		this.refreshDerived();
		for (let i = 0; i < this.count; i++) {
			const reg = this.region[i];
			const ww = this.w[i];
			let next = 0;
			if (!this.border[i] && !this.frozen[i] && ww >= .035 && reg >= 0) next = ww / (this.derived[reg]?.mass ?? 1);
			if (next === 0) {
				this.x[i] = this.rx[i];
				this.y[i] = this.ry[i];
				this.vx[i] = 0;
				this.vy[i] = 0;
				this.grabFall[i] = 0;
			}
			this.invMass[i] = next;
		}
	}
	refreshDerived() {
		const unit = this.imgW / 1e3;
		this.derived = this.params.map((params) => derive(params, unit));
	}
	step(dt) {
		if (!(dt > 0)) return;
		this.refreshDerived();
		const h = Math.min(dt, .033) / 4;
		for (let s = 0; s < 4; s++) this.integrate(h);
	}
	integrate(h) {
		const n = this.count;
		const ax = this.ax;
		const ay = this.ay;
		for (let i = 0; i < n; i++) {
			const im = this.invMass[i];
			const reg = this.region[i];
			const d = im === 0 ? void 0 : this.derived[reg];
			if (im === 0 || !d) {
				ax[i] = 0;
				ay[i] = 0;
				continue;
			}
			const edge = 1 - this.w[i];
			const kA = d.anchor * (.42 + 2.7 * edge * edge);
			ax[i] = (this.rx[i] - this.x[i]) * kA * im;
			ay[i] = (this.ry[i] - this.y[i]) * kA * im + d.gravity;
		}
		if (this.grabbing) {
			const d = this.derived[this.grabRegion];
			if (d) {
				const gdx = this.grabDX;
				const gdy = this.grabDY;
				for (let i = 0; i < n; i++) {
					const fall = this.grabFall[i];
					if (fall <= 0 || this.invMass[i] === 0) continue;
					const tx = this.rx[i] + gdx * fall * d.deform;
					const ty = this.ry[i] + gdy * fall * d.deform;
					const follow = d.grab * this.w[i];
					ax[i] += (tx - this.x[i]) * follow;
					ay[i] += (ty - this.y[i]) * follow;
				}
			}
		}
		for (let s = 0; s < this.springCount; s++) {
			const i = this.si[s];
			const j = this.sj[s];
			const imI = this.invMass[i];
			const imJ = this.invMass[j];
			if (imI === 0 && imJ === 0) continue;
			if (imI > 0 && imJ > 0 && this.region[i] !== this.region[j]) continue;
			const reg = imI > 0 ? this.region[i] : this.region[j];
			const d = this.derived[reg];
			if (!d) continue;
			const dx = this.x[j] - this.x[i];
			const dy = this.y[j] - this.y[i];
			const dist = Math.hypot(dx, dy) || 1e-4;
			const dirx = dx / dist;
			const diry = dy / dist;
			const rest = this.srest[s];
			let stretch = dist - rest;
			const limit = rest * 1.35;
			if (stretch > limit) stretch = limit;
			else if (stretch < -rest * .8) stretch = -rest * .8;
			const rel = (this.vx[j] - this.vx[i]) * dirx + (this.vy[j] - this.vy[i]) * diry;
			const k = this.skind[s] ? d.shear : d.stiff;
			let f = k * stretch + k * .06 * rel;
			if (f > 9e3) f = 9e3;
			else if (f < -9e3) f = -9e3;
			ax[i] += dirx * f * imI;
			ay[i] += diry * f * imI;
			ax[j] -= dirx * f * imJ;
			ay[j] -= diry * f * imJ;
		}
		const vmax = this.imgW * 2.4;
		for (let i = 0; i < n; i++) {
			if (this.invMass[i] === 0) {
				this.x[i] = this.rx[i];
				this.y[i] = this.ry[i];
				this.vx[i] = 0;
				this.vy[i] = 0;
				continue;
			}
			const d = this.derived[this.region[i]];
			let vx = (this.vx[i] + ax[i] * h) * Math.exp(-d.damp * h);
			let vy = (this.vy[i] + ay[i] * h) * Math.exp(-d.damp * h);
			const sp = Math.hypot(vx, vy);
			if (sp > vmax) {
				const s = vmax / sp;
				vx *= s;
				vy *= s;
			}
			let x = this.x[i] + vx * h;
			let y = this.y[i] + vy * h;
			let dx = x - this.rx[i];
			let dy = y - this.ry[i];
			const dist = Math.hypot(dx, dy);
			const maxD = d.maxDisp;
			if (dist > maxD && dist > 0) {
				const s = maxD / dist;
				x = this.rx[i] + dx * s;
				y = this.ry[i] + dy * s;
				const vn = (vx * dx + vy * dy) / (dist * dist);
				if (vn > 0) {
					vx -= vn * dx;
					vy -= vn * dy;
				}
				dx = x - this.rx[i];
				dy = y - this.ry[i];
			}
			if (!Number.isFinite(x) || !Number.isFinite(y)) {
				x = this.rx[i];
				y = this.ry[i];
				vx = 0;
				vy = 0;
			}
			this.x[i] = x;
			this.y[i] = y;
			this.vx[i] = vx;
			this.vy[i] = vy;
		}
	}
	beginGrab(ix, iy, region, radius) {
		this.grabFall.fill(0);
		const r = Math.max(12, radius);
		let any = false;
		for (let i = 0; i < this.count; i++) {
			if (this.region[i] !== region || this.invMass[i] === 0) continue;
			const dx = this.rx[i] - ix;
			const dy = this.ry[i] - iy;
			const dist = Math.hypot(dx, dy);
			if (dist > r) continue;
			const t = 1 - dist / r;
			this.grabFall[i] = t * t * (3 - 2 * t);
			any = true;
		}
		this.grabbing = any;
		this.grabRegion = region;
		this.grabDX = 0;
		this.grabDY = 0;
		return any;
	}
	updateGrab(dx, dy) {
		const maxD = this.derived[this.grabRegion]?.maxDisp ?? Infinity;
		const dist = Math.hypot(dx, dy);
		if (dist > maxD && dist > 0) {
			const s = maxD / dist;
			this.grabDX = dx * s;
			this.grabDY = dy * s;
		} else {
			this.grabDX = dx;
			this.grabDY = dy;
		}
	}
	endGrab() {
		this.grabbing = false;
		this.grabFall.fill(0);
	}
	get isGrabbing() {
		return this.grabbing;
	}
	tap(ix, iy, region, radius) {
		const d = this.derived[region];
		if (!d) return;
		const impulse = d.bounce;
		for (let i = 0; i < this.count; i++) {
			if (this.region[i] !== region || this.invMass[i] === 0) continue;
			const dx = this.x[i] - ix;
			const dy = this.y[i] - iy;
			const dist = Math.hypot(dx, dy);
			if (dist > radius) continue;
			const fall = (1 - dist / radius) ** 2 * this.w[i];
			const len = dist || 1;
			this.vx[i] += (dx / len * .55 + .12) * impulse * fall;
			this.vy[i] += (dy / len * .35 - .95) * impulse * fall;
		}
	}
	accelerate(ax, ay) {
		for (let i = 0; i < this.count; i++) {
			if (this.invMass[i] === 0) continue;
			this.vx[i] += ax * this.w[i];
			this.vy[i] += ay * this.w[i];
		}
	}
	applyBrush(kind, ix, iy, radius, power, region, time) {
		const r = Math.max(4, radius);
		for (let i = 0; i < this.count; i++) {
			if (region >= 0 && this.region[i] !== region) continue;
			if (this.invMass[i] === 0) continue;
			const dx = this.x[i] - ix;
			const dy = this.y[i] - iy;
			const dist = Math.hypot(dx, dy);
			if (dist > r) continue;
			const fall = (1 - dist / r) ** 2;
			const len = dist || 1;
			const f = power * fall * this.w[i];
			if (kind === "push") {
				this.vx[i] += dx / len * f;
				this.vy[i] += dy / len * f;
			} else if (kind === "pull") {
				this.vx[i] -= dx / len * f;
				this.vy[i] -= dy / len * f;
			} else if (kind === "jiggle") {
				const wob = Math.sin(time * .028 + i * .35);
				this.vx[i] += Math.cos(time * .02 + i) * f * .85;
				this.vy[i] += wob * f;
			} else {
				this.vx[i] += (this.rx[i] - this.x[i]) * f * .08;
				this.vy[i] += (this.ry[i] - this.y[i]) * f * .08;
				this.vx[i] *= .8;
				this.vy[i] *= .8;
			}
		}
	}
	resetRegion(region) {
		for (let i = 0; i < this.count; i++) {
			if (this.region[i] !== region) continue;
			this.x[i] = this.rx[i];
			this.y[i] = this.ry[i];
			this.vx[i] = 0;
			this.vy[i] = 0;
		}
		if (this.grabRegion === region) this.endGrab();
	}
	maxOffset(region = -1) {
		let m = 0;
		for (let i = 0; i < this.count; i++) {
			if (region >= 0 && this.region[i] !== region) continue;
			const d = Math.hypot(this.x[i] - this.rx[i], this.y[i] - this.ry[i]);
			if (d > m) m = d;
		}
		return m;
	}
	dynamicCount(region = -1) {
		let n = 0;
		for (let i = 0; i < this.count; i++) {
			if (this.invMass[i] === 0) continue;
			if (region >= 0 && this.region[i] !== region) continue;
			n++;
		}
		return n;
	}
};
var SCULPT_TOOLS = [
	"jiggle",
	"push",
	"pull",
	"smooth",
	"freeze",
	"restore"
];
function toolMode(tool) {
	if (tool === "interact" || SCULPT_TOOLS.includes(tool)) return "play";
	return "select";
}
function defaultBrush() {
	return {
		size: 56,
		strength: 78,
		softness: 62,
		opacity: 52,
		additive: true,
		tolerance: 36
	};
}
var REGION_COLORS = [
	"#ff7a45",
	"#3ee0b0",
	"#7aa2ff",
	"#ffd166",
	"#f472b6",
	"#c084fc",
	"#67e8f9",
	"#bef264"
];
var VERT = `
attribute vec2 aPos;
attribute vec2 aUV;
uniform vec2 uOrigin;
uniform float uZoom;
uniform vec2 uView;
varying vec2 vUV;
void main() {
  vec2 screen = (aPos - uOrigin) * uZoom;
  vec2 clip = vec2(screen.x / uView.x * 2.0 - 1.0, 1.0 - screen.y / uView.y * 2.0);
  gl_Position = vec4(clip, 0.0, 1.0);
  vUV = aUV;
}
`;
var FRAG = `
precision mediump float;
varying vec2 vUV;
uniform sampler2D uImage;
uniform sampler2D uMask;
uniform float uOverlay;
void main() {
  vec4 base = texture2D(uImage, vUV);
  vec4 ov = texture2D(uMask, vUV);
  float cells = mod(floor(gl_FragCoord.x / 12.0) + floor(gl_FragCoord.y / 12.0), 2.0);
  vec3 board = mix(vec3(0.047, 0.055, 0.071), vec3(0.09, 0.105, 0.135), cells);
  vec3 rgb = mix(board, base.rgb, base.a);
  rgb = mix(rgb, ov.rgb, clamp(ov.a * uOverlay, 0.0, 0.72));
  gl_FragColor = vec4(rgb, 1.0);
}
`;
var WIRE_FRAG = `
precision mediump float;
uniform vec4 uColor;
void main() { gl_FragColor = uColor; }
`;
var MASK_LONG = 960;
function compile(gl, type, src) {
	const shader = gl.createShader(type);
	if (!shader) throw new Error("shader");
	gl.shaderSource(shader, src);
	gl.compileShader(shader);
	if (!gl.getShaderParameter(shader, gl.COMPILE_STATUS)) throw new Error(gl.getShaderInfoLog(shader) || "shader compile");
	return shader;
}
function program(gl, vs, fs) {
	const p = gl.createProgram();
	if (!p) throw new Error("program");
	gl.attachShader(p, compile(gl, gl.VERTEX_SHADER, vs));
	gl.attachShader(p, compile(gl, gl.FRAGMENT_SHADER, fs));
	gl.bindAttribLocation(p, 0, "aPos");
	gl.bindAttribLocation(p, 1, "aUV");
	gl.linkProgram(p);
	if (!gl.getProgramParameter(p, gl.LINK_STATUS)) throw new Error(gl.getProgramInfoLog(p) || "link");
	return p;
}
function makeTexture(gl) {
	const tex = gl.createTexture();
	if (!tex) throw new Error("texture");
	gl.bindTexture(gl.TEXTURE_2D, tex);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
	gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
	gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, 1, 1, 0, gl.RGBA, gl.UNSIGNED_BYTE, new Uint8Array([
		0,
		0,
		0,
		0
	]));
	return tex;
}
function createPipe(canvas) {
	const gl = canvas.getContext("webgl", {
		alpha: false,
		antialias: true,
		premultipliedAlpha: false,
		preserveDrawingBuffer: true,
		powerPreference: "high-performance"
	});
	if (!gl) return null;
	const prog = program(gl, VERT, FRAG);
	const wire = program(gl, VERT, WIRE_FRAG);
	const buffer = () => {
		const b = gl.createBuffer();
		if (!b) throw new Error("buffer");
		return b;
	};
	return {
		gl,
		program: prog,
		wire,
		pos: buffer(),
		uv: buffer(),
		idx: buffer(),
		lines: buffer(),
		image: makeTexture(gl),
		mask: makeTexture(gl),
		aPos: 0,
		aUV: 1,
		uOrigin: gl.getUniformLocation(prog, "uOrigin"),
		uZoom: gl.getUniformLocation(prog, "uZoom"),
		uView: gl.getUniformLocation(prog, "uView"),
		uImage: gl.getUniformLocation(prog, "uImage"),
		uMask: gl.getUniformLocation(prog, "uMask"),
		uOverlay: gl.getUniformLocation(prog, "uOverlay"),
		wOrigin: gl.getUniformLocation(wire, "uOrigin"),
		wZoom: gl.getUniformLocation(wire, "uZoom"),
		wView: gl.getUniformLocation(wire, "wView") ?? gl.getUniformLocation(wire, "uView"),
		wColor: gl.getUniformLocation(wire, "uColor")
	};
}
function loadImage(src) {
	return new Promise((resolve, reject) => {
		const img = new Image();
		img.onload = () => resolve(img);
		img.onerror = () => reject(/* @__PURE__ */ new Error("Could not read that image"));
		img.src = src;
	});
}
function readFile(file) {
	return new Promise((resolve, reject) => {
		const reader = new FileReader();
		reader.onload = () => resolve(String(reader.result));
		reader.onerror = () => reject(reader.error);
		reader.readAsDataURL(file);
	});
}
function maskToPng(mask, w, h) {
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	if (!ctx) return "";
	const image = ctx.createImageData(w, h);
	for (let i = 0; i < mask.length; i++) {
		image.data[i * 4] = mask[i];
		image.data[i * 4 + 3] = 255;
	}
	ctx.putImageData(image, 0, 0);
	return canvas.toDataURL("image/png");
}
async function pngToMask(url, w, h) {
	const img = await loadImage(url);
	const canvas = document.createElement("canvas");
	canvas.width = w;
	canvas.height = h;
	const ctx = canvas.getContext("2d");
	const mask = new Uint8Array(w * h);
	if (!ctx) return mask;
	ctx.drawImage(img, 0, 0, w, h);
	const data = ctx.getImageData(0, 0, w, h).data;
	for (let i = 0; i < mask.length; i++) mask[i] = data[i * 4];
	return mask;
}
var JiggleEngine = class {
	onChange = null;
	onProject = null;
	tool = "soft";
	brush = defaultBrush();
	quality = 46;
	shakeSensitivity = 55;
	overlay = true;
	showMesh = false;
	paused = false;
	space = false;
	canvas;
	overlayCanvas;
	octx;
	pipe = null;
	exportPipe = null;
	exportCanvas = null;
	sim = null;
	regions = /* @__PURE__ */ new Map();
	order = [];
	activeId = null;
	undoStack = [];
	redoStack = [];
	workCanvas = null;
	pixels = null;
	dataUrl = null;
	naturalW = 0;
	naturalH = 0;
	workW = 0;
	workH = 0;
	mw = 0;
	mh = 0;
	originX = 0;
	originY = 0;
	zoom = 1;
	dpr = 1;
	didFit = false;
	weightsDirty = false;
	overlayDirty = false;
	hasSelection = false;
	imageReady = false;
	glFailed = false;
	maxTex = 4096;
	maxViewport = 4096;
	pos = /* @__PURE__ */ new Float32Array(0);
	uv = /* @__PURE__ */ new Float32Array(0);
	indices = /* @__PURE__ */ new Uint16Array(0);
	lineIdx = /* @__PURE__ */ new Uint16Array(0);
	triCount = 0;
	wBuf = /* @__PURE__ */ new Float32Array(0);
	rBuf = /* @__PURE__ */ new Int16Array(0);
	fBuf = /* @__PURE__ */ new Uint8Array(0);
	overlayPixels = /* @__PURE__ */ new Uint8Array(0);
	raf = 0;
	last = 0;
	disposed = false;
	painting = false;
	panning = false;
	pinching = false;
	grabPoint = null;
	grabRegion = -1;
	downCss = {
		x: 0,
		y: 0
	};
	downTime = 0;
	lastMask = null;
	polyImage = [];
	pointers = /* @__PURE__ */ new Map();
	pinchPrev = null;
	panLast = {
		x: 0,
		y: 0
	};
	cursor = null;
	shakeT = 0;
	shakePhase = 0;
	shakeAng = 0;
	shakeAmp = 1;
	emitQueued = false;
	ro = null;
	onDown;
	onMove;
	onUp;
	onWheel;
	onCtx;
	constructor(canvas, overlay) {
		this.canvas = canvas;
		this.overlayCanvas = overlay;
		this.octx = overlay.getContext("2d");
		try {
			this.pipe = createPipe(canvas);
			if (!this.pipe) this.glFailed = true;
			else {
				this.maxTex = this.pipe.gl.getParameter(this.pipe.gl.MAX_TEXTURE_SIZE);
				const vp = this.pipe.gl.getParameter(this.pipe.gl.MAX_VIEWPORT_DIMS);
				this.maxViewport = vp[0] || 4096;
			}
		} catch {
			this.pipe = null;
			this.glFailed = true;
		}
		this.onDown = (e) => this.pointerDown(e);
		this.onMove = (e) => this.pointerMove(e);
		this.onUp = (e) => this.pointerUp(e);
		this.onWheel = (e) => {
			e.preventDefault();
			const css = this.cssOf(e.clientX, e.clientY);
			const factor = Math.exp(-e.deltaY * .0011);
			this.zoomAt(css.x, css.y, factor);
		};
		this.onCtx = (e) => e.preventDefault();
		canvas.addEventListener("pointerdown", this.onDown);
		canvas.addEventListener("pointermove", this.onMove);
		window.addEventListener("pointerup", this.onUp);
		window.addEventListener("pointercancel", this.onUp);
		canvas.addEventListener("wheel", this.onWheel, { passive: false });
		canvas.addEventListener("contextmenu", this.onCtx);
		this.ro = new ResizeObserver(() => this.resize());
		this.ro.observe(canvas);
		this.resize();
		this.last = performance.now();
		this.raf = requestAnimationFrame(this.frame);
	}
	destroy() {
		this.disposed = true;
		cancelAnimationFrame(this.raf);
		this.ro?.disconnect();
		this.canvas.removeEventListener("pointerdown", this.onDown);
		this.canvas.removeEventListener("pointermove", this.onMove);
		window.removeEventListener("pointerup", this.onUp);
		window.removeEventListener("pointercancel", this.onUp);
		this.canvas.removeEventListener("wheel", this.onWheel);
		this.canvas.removeEventListener("contextmenu", this.onCtx);
		this.pipe?.gl.getExtension("WEBGL_lose_context")?.loseContext();
		this.exportPipe?.gl.getExtension("WEBGL_lose_context")?.loseContext();
	}
	frame = (now) => {
		if (this.disposed) return;
		const dt = Math.min(.05, (now - this.last) / 1e3);
		this.last = now;
		if (this.weightsDirty) this.resample();
		this.tickShake(dt);
		if (this.sim && (!this.paused || this.sim.isGrabbing)) this.sim.step(dt);
		this.render();
		this.raf = requestAnimationFrame(this.frame);
	};
	tickShake(dt) {
		if (this.shakeT <= 0 || !this.sim) return;
		const unit = this.workW / 1e3 || 1;
		const amp = lerp(280, 3400, this.shakeSensitivity / 100) * unit * this.shakeAmp;
		const wave = Math.sin(this.shakePhase) * amp * Math.min(1, this.shakeT * 4);
		this.sim.accelerate(Math.cos(this.shakeAng) * wave * dt, Math.sin(this.shakeAng) * wave * dt);
		this.shakePhase += dt * 34;
		this.shakeT -= dt;
	}
	shake(scale = 1) {
		this.shakeT = .62;
		this.shakeAmp = scale;
		this.shakeAng = Math.random() * Math.PI * 2;
		this.shakePhase = 0;
	}
	applyMotion(ax, ay) {
		if (!this.sim || this.paused) return;
		const sens = this.shakeSensitivity / 100;
		const mag = Math.hypot(ax, ay);
		const threshold = lerp(14, 1.5, sens);
		if (mag < threshold) return;
		const unit = this.workW / 1e3 || 1;
		const gain = lerp(8, 90, sens) * unit;
		const s = (mag - threshold) / Math.max(mag, .001) * gain * .02;
		this.sim.accelerate(ax * s, -ay * s);
	}
	resize() {
		const dpr = Math.min(window.devicePixelRatio || 1, 2);
		const w = Math.max(1, this.canvas.clientWidth);
		const h = Math.max(1, this.canvas.clientHeight);
		const bw = Math.max(1, Math.round(w * dpr));
		const bh = Math.max(1, Math.round(h * dpr));
		if (this.canvas.width !== bw || this.canvas.height !== bh) {
			this.canvas.width = bw;
			this.canvas.height = bh;
			this.overlayCanvas.width = bw;
			this.overlayCanvas.height = bh;
		}
		this.dpr = dpr;
		if (this.imageReady && !this.didFit && w > 2 && h > 2) {
			this.fit();
			this.didFit = true;
		}
	}
	fit() {
		if (!this.workW || !this.canvas.clientWidth) return;
		const z = Math.min(this.canvas.clientWidth / this.workW, this.canvas.clientHeight / this.workH) * .92;
		this.zoom = clamp(z, .02, 32);
		this.originX = (this.workW - this.canvas.clientWidth / this.zoom) / 2;
		this.originY = (this.workH - this.canvas.clientHeight / this.zoom) / 2;
		this.emit();
	}
	zoomBy(factor) {
		const x = this.canvas.clientWidth / 2;
		const y = this.canvas.clientHeight / 2;
		this.zoomAt(x, y, factor);
	}
	zoomAt(cssX, cssY, factor) {
		if (!this.imageReady) return;
		const ix = this.originX + cssX / this.zoom;
		const iy = this.originY + cssY / this.zoom;
		const minZ = Math.min(this.canvas.clientWidth / this.workW, this.canvas.clientHeight / this.workH) * .2;
		this.zoom = clamp(this.zoom * factor, minZ, 16);
		this.originX = ix - cssX / this.zoom;
		this.originY = iy - cssY / this.zoom;
		this.emit();
	}
	cssOf(clientX, clientY) {
		const rect = this.canvas.getBoundingClientRect();
		return {
			x: clientX - rect.left,
			y: clientY - rect.top
		};
	}
	imageOf(cssX, cssY) {
		return {
			x: this.originX + cssX / this.zoom,
			y: this.originY + cssY / this.zoom
		};
	}
	toMask(ix, iy) {
		return {
			x: ix / this.workW * this.mw,
			y: iy / this.workH * this.mh
		};
	}
	async loadFile(file) {
		const dataUrl = await readFile(file);
		await this.loadDataUrl(dataUrl);
	}
	async loadDataUrl(dataUrl) {
		const img = await loadImage(dataUrl);
		await this.loadSource(img, img.naturalWidth, img.naturalHeight, dataUrl);
	}
	async loadSource(source, naturalW, naturalH, dataUrl) {
		if (!naturalW || !naturalH) throw new Error("That image has no pixels");
		this.naturalW = naturalW;
		this.naturalH = naturalH;
		this.dataUrl = dataUrl;
		const limit = Math.min(this.maxTex || 4096, 4096);
		let w = naturalW;
		let h = naturalH;
		if (w > limit || h > limit) {
			const s = limit / Math.max(w, h);
			w = Math.max(2, Math.round(naturalW * s));
			h = Math.max(2, Math.round(naturalH * s));
		}
		this.workW = w;
		this.workH = h;
		const canvas = document.createElement("canvas");
		canvas.width = w;
		canvas.height = h;
		const ctx = canvas.getContext("2d");
		if (!ctx) throw new Error("Could not prepare the image");
		ctx.drawImage(source, 0, 0, w, h);
		this.workCanvas = canvas;
		this.imageReady = true;
		this.didFit = false;
		this.undoStack = [];
		this.redoStack = [];
		this.polyImage = [];
		const scale = MASK_LONG / Math.max(w, h);
		this.mw = Math.max(2, Math.round(w * scale));
		this.mh = Math.max(2, Math.round(h * scale));
		this.allocMasks(true);
		const sample = document.createElement("canvas");
		sample.width = this.mw;
		sample.height = this.mh;
		const sctx = sample.getContext("2d");
		if (sctx) {
			sctx.drawImage(canvas, 0, 0, this.mw, this.mh);
			this.pixels = sctx.getImageData(0, 0, this.mw, this.mh).data;
		}
		this.uploadImage(canvas);
		this.rebuildSim();
		this.overlayDirty = true;
		this.weightsDirty = true;
		this.resize();
		if (this.canvas.clientWidth > 2) {
			this.fit();
			this.didFit = true;
		}
		this.emit();
	}
	allocMasks(clear) {
		const n = this.mw * this.mh;
		for (const rec of this.regions.values()) if (clear || rec.mask.length !== n) {
			rec.mask = new Uint8Array(n);
			rec.freeze = new Uint8Array(n);
		}
	}
	syncRegions(list, activeId) {
		const n = this.mw * this.mh;
		const next = /* @__PURE__ */ new Map();
		for (const meta of list) {
			const prev = this.regions.get(meta.id);
			const mask = prev && prev.mask.length === n ? prev.mask : new Uint8Array(n);
			const freeze = prev && prev.freeze.length === n ? prev.freeze : new Uint8Array(n);
			next.set(meta.id, {
				meta,
				mask,
				freeze
			});
		}
		this.regions = next;
		this.order = list.map((region) => region.id);
		this.activeId = activeId;
		this.weightsDirty = true;
		this.overlayDirty = true;
		this.refreshSelection();
	}
	setBrush(brush) {
		if (brush.opacity !== this.brush.opacity) this.overlayDirty = true;
		this.brush = brush;
	}
	clearImage() {
		this.sim?.endGrab();
		this.imageReady = false;
		this.sim = null;
		this.workCanvas = null;
		this.dataUrl = null;
		this.pixels = null;
		this.regions.clear();
		this.order = [];
		this.activeId = null;
		this.undoStack = [];
		this.redoStack = [];
		this.polyImage = [];
		this.hasSelection = false;
		this.naturalW = 0;
		this.naturalH = 0;
		this.didFit = false;
		this.emit();
	}
	selectWarmSubject() {
		const rec = this.activeRec();
		if (!rec || !this.pixels) return;
		this.pushHistory(rec);
		const n = this.mw * this.mh;
		const temp = new Uint8Array(n);
		const pix = this.pixels;
		for (let i = 0; i < n; i++) {
			const r = pix[i * 4];
			const g = pix[i * 4 + 1];
			const b = pix[i * 4 + 2];
			const max = Math.max(r, g, b);
			const min = Math.min(r, g, b);
			if (r > 58 && r >= g - 8 && r > b + 6 && max - min > 16) temp[i] = 255;
		}
		rec.mask.set(boxBlur(temp, this.mw, this.mh, 5, 2));
		this.markMask();
	}
	clearActiveMask() {
		const rec = this.activeRec();
		if (!rec) return;
		this.pushHistory(rec);
		rec.mask.fill(0);
		rec.freeze.fill(0);
		this.markMask();
	}
	resetRegion(id) {
		const idx = this.order.indexOf(id);
		const rec = this.regions.get(id);
		if (!rec || idx < 0) return;
		this.pushHistory(rec);
		rec.freeze.fill(0);
		this.weightsDirty = true;
		this.overlayDirty = true;
		this.resample();
		this.sim?.resetRegion(idx);
		this.emit();
	}
	undo() {
		this.restore(this.undoStack, this.redoStack);
	}
	redo() {
		this.restore(this.redoStack, this.undoStack);
	}
	restore(from, to) {
		const entry = from.pop();
		if (!entry) return;
		const rec = this.regions.get(entry.id);
		if (!rec || rec.mask.length !== entry.mask.length) return;
		to.push({
			id: entry.id,
			mask: rec.mask.slice(),
			freeze: rec.freeze.slice()
		});
		rec.mask.set(entry.mask);
		rec.freeze.set(entry.freeze);
		this.markMask();
	}
	setQuality(quality) {
		this.quality = quality;
		if (this.imageReady) this.rebuildSim();
	}
	closePolygon() {
		if (this.polyImage.length >= 3) this.commitShape(this.polyImage);
		else this.polyImage = [];
	}
	cancelShape() {
		this.polyImage = [];
		this.painting = false;
	}
	async ingestProject(project) {
		if (project.app !== "wobble" || project.version !== 1 || !project.image) throw new Error("That file is not a Wobble project");
		await this.loadDataUrl(project.image);
		const metas = [];
		const next = /* @__PURE__ */ new Map();
		for (const region of project.regions) {
			const meta = {
				id: region.id,
				name: region.name,
				color: region.color,
				visible: region.visible !== false,
				params: { ...region.params }
			};
			next.set(meta.id, {
				meta,
				mask: await pngToMask(region.mask, this.mw, this.mh),
				freeze: await pngToMask(region.freeze || region.mask, this.mw, this.mh)
			});
			if (!region.freeze) next.get(meta.id).freeze.fill(0);
			metas.push(meta);
		}
		this.regions = next;
		this.order = metas.map((region) => region.id);
		this.activeId = project.activeId && next.has(project.activeId) ? project.activeId : metas[0]?.id ?? null;
		this.quality = project.quality || this.quality;
		this.shakeSensitivity = project.shake ?? this.shakeSensitivity;
		this.brush = {
			...this.brush,
			opacity: project.opacity ?? this.brush.opacity
		};
		this.overlay = project.overlay !== false;
		this.rebuildSim();
		this.markMask();
		this.onProject?.(project, metas);
	}
	async toProject(extra) {
		const image = this.dataUrl ?? this.workCanvas?.toDataURL("image/jpeg", .92) ?? "";
		const regions = this.order.map((id) => {
			const rec = this.regions.get(id);
			return {
				...rec.meta,
				params: { ...rec.meta.params },
				mask: maskToPng(rec.mask, this.mw, this.mh),
				freeze: maskToPng(rec.freeze, this.mw, this.mh)
			};
		});
		return {
			version: 1,
			app: "wobble",
			image,
			activeId: this.activeId,
			quality: extra.quality,
			shake: extra.shake,
			opacity: extra.opacity,
			overlay: extra.overlay,
			regions
		};
	}
	async exportPNG() {
		if (!this.imageReady || !this.sim || !this.workCanvas) throw new Error("Load an image first");
		const maxDim = Math.min(this.maxViewport || 4096, 8192);
		let ew = this.naturalW;
		let eh = this.naturalH;
		if (ew > maxDim || eh > maxDim) {
			const s = maxDim / Math.max(ew, eh);
			ew = Math.max(2, Math.round(this.naturalW * s));
			eh = Math.max(2, Math.round(this.naturalH * s));
		}
		const canvas = this.exportCanvas ?? document.createElement("canvas");
		this.exportCanvas = canvas;
		if (canvas.width !== ew || canvas.height !== eh) {
			canvas.width = ew;
			canvas.height = eh;
		}
		if (!this.exportPipe) {
			this.exportPipe = createPipe(canvas);
			if (!this.exportPipe) throw new Error("Could not export this image");
			this.uploadImageTo(this.exportPipe, this.workCanvas);
		} else if (this.exportPipe.gl.canvas !== canvas) {
			this.exportPipe = createPipe(canvas);
			if (!this.exportPipe) throw new Error("Could not export this image");
			this.uploadImageTo(this.exportPipe, this.workCanvas);
		}
		this.uploadMesh(this.exportPipe, ew / this.workW, eh / this.workH);
		this.draw(this.exportPipe, 0, 0, 1, ew, eh, ew, eh, false);
		const blob = await new Promise((resolve) => canvas.toBlob(resolve, "image/png"));
		if (!blob) throw new Error("Could not encode PNG");
		return blob;
	}
	async exportVideo(seconds = 3) {
		const canvas = this.canvas;
		if (typeof canvas.captureStream !== "function" || typeof MediaRecorder === "undefined") throw new Error("This browser cannot record video");
		const mime = [
			"video/webm;codecs=vp9",
			"video/webm;codecs=vp8",
			"video/webm"
		].find((type) => MediaRecorder.isTypeSupported(type));
		if (!mime) throw new Error("This browser cannot record video");
		const stream = canvas.captureStream(30);
		const rec = new MediaRecorder(stream, { mimeType: mime });
		const chunks = [];
		rec.ondataavailable = (event) => {
			if (event.data.size) chunks.push(event.data);
		};
		const done = new Promise((resolve) => {
			rec.onstop = () => resolve(new Blob(chunks, { type: mime }));
		});
		this.shake(1);
		rec.start();
		await new Promise((resolve) => setTimeout(resolve, seconds * 1e3));
		rec.stop();
		return done;
	}
	async exportGIF(seconds = 2) {
		if (!this.imageReady) throw new Error("Load an image first");
		const maxW = 440;
		const cssW = Math.max(2, this.canvas.clientWidth);
		const cssH = Math.max(2, this.canvas.clientHeight);
		const scale = Math.min(1, maxW / cssW);
		const w = Math.max(2, Math.round(cssW * scale));
		const h = Math.max(2, Math.round(cssH * scale));
		const canvas = document.createElement("canvas");
		canvas.width = w;
		canvas.height = h;
		const ctx = canvas.getContext("2d", { willReadFrequently: true });
		if (!ctx) throw new Error("Could not encode GIF");
		const frames = [];
		const count = Math.round(seconds * 10);
		const delay = Math.round(100);
		const wasPaused = this.paused;
		this.paused = false;
		this.shake(1);
		for (let i = 0; i < count; i++) {
			this.tickShake(delay / 1e3);
			this.sim?.step(delay / 1e3);
			this.render();
			ctx.drawImage(this.canvas, 0, 0, w, h);
			frames.push(ctx.getImageData(0, 0, w, h).data);
			await new Promise((resolve) => setTimeout(resolve, 0));
		}
		this.paused = wasPaused;
		const gifenc = await import("../_libs/gifenc.mjs").then((n) => n.t);
		const gif = gifenc.GIFEncoder();
		for (let i = 0; i < frames.length; i++) {
			const data = frames[i];
			const palette = gifenc.quantize(data, 128);
			const index = gifenc.applyPalette(data, palette);
			gif.writeFrame(index, w, h, {
				palette,
				delay,
				repeat: 0
			});
		}
		gif.finish();
		return new Blob([gif.bytes().slice()], { type: "image/gif" });
	}
	debug() {
		return {
			maxOffset: this.sim?.maxOffset() ?? 0,
			dynamic: this.sim?.dynamicCount() ?? 0,
			verts: this.sim?.count ?? 0,
			cols: this.sim?.cols ?? 0,
			rows: this.sim?.rows ?? 0,
			hasSelection: this.hasSelection,
			zoom: this.zoom,
			workW: this.workW,
			workH: this.workH,
			glFailed: this.glFailed,
			regions: this.order.length
		};
	}
	exercise() {
		if (!this.sim) return {
			ok: false,
			reason: "no-sim"
		};
		const ix = this.workW * .5;
		const iy = this.workH * .48;
		const region = this.hitRegion(ix, iy);
		if (region < 0) return {
			ok: false,
			reason: "no-hit",
			...this.debug()
		};
		const radius = Math.min(this.workW, this.workH) * .4;
		const grabbed = this.sim.beginGrab(ix, iy, region, radius);
		let peak = 0;
		const pull = this.workW * .1;
		for (let f = 1; f <= 24; f++) {
			this.sim.updateGrab(f / 24 * pull, f / 24 * this.workH * .03);
			this.sim.step(1 / 60);
			peak = Math.max(peak, this.sim.maxOffset(region));
		}
		this.sim.endGrab();
		const samples = [];
		for (let f = 0; f < 120; f++) {
			this.sim.step(1 / 60);
			if (f % 10 === 0) samples.push(Number(this.sim.maxOffset(region).toFixed(2)));
		}
		const end = this.sim.maxOffset(region);
		const others = this.order.map((_, index) => this.sim?.maxOffset(index) ?? 0);
		return {
			ok: grabbed && peak > 6 && end < peak * .55,
			grabbed,
			peak,
			end,
			samples,
			region,
			others,
			dynamic: this.sim.dynamicCount()
		};
	}
	pointerDown(e) {
		if (e.button === 2) return;
		this.canvas.setPointerCapture?.(e.pointerId);
		const css = this.cssOf(e.clientX, e.clientY);
		this.pointers.set(e.pointerId, css);
		if (this.pointers.size >= 2) {
			this.pinching = true;
			this.painting = false;
			this.panning = false;
			this.sim?.endGrab();
			this.pinchPrev = this.pinchMetrics();
			return;
		}
		if (!this.imageReady) return;
		if (this.space || e.button === 1 || this.tool === "pan") {
			this.panning = true;
			this.panLast = css;
			return;
		}
		const image = this.imageOf(css.x, css.y);
		this.downCss = css;
		this.downTime = performance.now();
		if (this.tool === "polygon") {
			if (this.polyImage.length >= 3) {
				const first = this.polyImage[0];
				if (Math.hypot(first.x - image.x, first.y - image.y) < 14 / this.zoom) {
					this.commitShape(this.polyImage);
					return;
				}
			}
			this.polyImage = [...this.polyImage, image];
			return;
		}
		if (this.tool === "fill") {
			this.doFill(image.x, image.y);
			return;
		}
		if (this.tool === "lasso") {
			this.painting = true;
			this.polyImage = [image];
			return;
		}
		if (this.tool === "interact") {
			const region = this.hitRegion(image.x, image.y);
			if (region < 0 || !this.sim) return;
			const params = this.regions.get(this.order[region])?.meta.params;
			const radius = Math.min(this.workW, this.workH) * lerp(.2, .48, (params?.deform ?? 60) / 100);
			if (this.sim.beginGrab(image.x, image.y, region, radius)) {
				this.painting = true;
				this.grabPoint = image;
				this.grabRegion = region;
			}
			return;
		}
		if (this.tool === "jiggle" || this.tool === "push" || this.tool === "pull" || this.tool === "restore") {
			this.painting = true;
			this.applyForce(image.x, image.y);
			return;
		}
		const rec = this.activeRec();
		if (!rec) return;
		this.pushHistory(rec);
		this.painting = true;
		this.lastMask = null;
		this.paintAt(image.x, image.y);
	}
	pointerMove(e) {
		const css = this.cssOf(e.clientX, e.clientY);
		if (this.pointers.has(e.pointerId)) this.pointers.set(e.pointerId, css);
		this.cursor = css;
		if (this.pinching && this.pointers.size >= 2) {
			const now = this.pinchMetrics();
			if (now && this.pinchPrev) {
				const factor = now.dist / this.pinchPrev.dist;
				this.zoomAt(now.midX, now.midY, factor);
				this.originX -= (now.midX - this.pinchPrev.midX) / this.zoom;
				this.originY -= (now.midY - this.pinchPrev.midY) / this.zoom;
				this.pinchPrev = now;
			}
			return;
		}
		if (this.panning) {
			this.originX -= (css.x - this.panLast.x) / this.zoom;
			this.originY -= (css.y - this.panLast.y) / this.zoom;
			this.panLast = css;
			return;
		}
		if (!this.painting || !this.imageReady) return;
		const image = this.imageOf(css.x, css.y);
		if (this.tool === "lasso") {
			const last = this.polyImage[this.polyImage.length - 1];
			if (!last || Math.hypot(last.x - image.x, last.y - image.y) > 2 / this.zoom) this.polyImage.push(image);
			return;
		}
		if (this.tool === "interact" && this.grabPoint && this.sim) {
			this.sim.updateGrab(image.x - this.grabPoint.x, image.y - this.grabPoint.y);
			return;
		}
		if (this.tool === "jiggle" || this.tool === "push" || this.tool === "pull" || this.tool === "restore") {
			this.applyForce(image.x, image.y);
			return;
		}
		this.paintAt(image.x, image.y);
	}
	pointerUp(e) {
		const css = this.pointers.get(e.pointerId) ?? this.cssOf(e.clientX, e.clientY);
		this.pointers.delete(e.pointerId);
		if (this.pointers.size < 2) {
			this.pinching = false;
			this.pinchPrev = null;
		}
		if (this.panning) {
			this.panning = false;
			this.emit();
			return;
		}
		if (this.tool === "lasso" && this.painting) {
			this.painting = false;
			if (this.polyImage.length > 2) {
				const first = this.polyImage[0];
				this.polyImage.push(first);
				this.commitShape(this.polyImage);
			}
			this.polyImage = [];
			return;
		}
		if (this.tool === "interact" && this.painting && this.grabPoint && this.sim) {
			const image = this.imageOf(css.x, css.y);
			const moved = Math.hypot(css.x - this.downCss.x, css.y - this.downCss.y);
			const quick = performance.now() - this.downTime < 260;
			const region = this.grabRegion;
			this.sim.endGrab();
			this.painting = false;
			if (quick && moved < 8 && region >= 0) {
				const radius = Math.min(this.workW, this.workH) * .22;
				this.sim.tap(image.x, image.y, region, radius);
			}
			this.grabPoint = null;
			return;
		}
		if (this.painting) {
			this.painting = false;
			this.lastMask = null;
			this.refreshSelection();
			this.emit();
		}
	}
	pinchMetrics() {
		const pts = [...this.pointers.values()];
		if (pts.length < 2) return null;
		const dx = pts[0].x - pts[1].x;
		const dy = pts[0].y - pts[1].y;
		return {
			dist: Math.max(1, Math.hypot(dx, dy)),
			midX: (pts[0].x + pts[1].x) / 2,
			midY: (pts[0].y + pts[1].y) / 2
		};
	}
	paintAt(ix, iy) {
		const rec = this.activeRec();
		if (!rec) return;
		const target = this.tool === "freeze" ? rec.freeze : rec.mask;
		const m = this.toMask(ix, iy);
		const radius = Math.max(1, this.brush.size * .5 / this.zoom / this.workW * this.mw);
		if (this.tool === "smooth") {
			smoothBrush(rec.mask, this.mw, this.mh, m.x, m.y, radius, this.brush.strength / 100);
			this.markMask();
			this.lastMask = m;
			return;
		}
		const hard = this.tool === "hard";
		const add = this.tool === "eraser" ? false : this.tool === "freeze" ? this.brush.additive : this.brush.additive;
		const stamp = (x, y) => stampBrush(target, this.mw, this.mh, x, y, radius, this.brush.strength / 100, this.brush.softness / 100, add, hard);
		if (this.lastMask) {
			const dist = Math.hypot(m.x - this.lastMask.x, m.y - this.lastMask.y);
			const step = Math.max(1, radius * .22);
			const steps = Math.max(1, Math.ceil(dist / step));
			for (let s = 1; s <= steps; s++) {
				const t = s / steps;
				stamp(this.lastMask.x + (m.x - this.lastMask.x) * t, this.lastMask.y + (m.y - this.lastMask.y) * t);
			}
		} else stamp(m.x, m.y);
		this.lastMask = m;
		this.markMask();
	}
	applyForce(ix, iy) {
		if (!this.sim) return;
		const region = this.hitRegion(ix, iy);
		const useRegion = region >= 0 ? region : this.order.indexOf(this.activeId ?? "");
		const radius = Math.max(8, this.brush.size * .5 / this.zoom);
		const unit = this.workW / 1e3 || 1;
		const power = lerp(30, 980, this.brush.strength / 100) * unit;
		const kind = this.tool === "push" || this.tool === "pull" || this.tool === "restore" || this.tool === "jiggle" ? this.tool : "jiggle";
		this.sim.applyBrush(kind, ix, iy, radius, power, useRegion, performance.now());
	}
	doFill(ix, iy) {
		const rec = this.activeRec();
		if (!rec || !this.pixels) return;
		this.pushHistory(rec);
		const m = this.toMask(ix, iy);
		const tol = lerp(6, 150, this.brush.tolerance / 100);
		let temp = floodFill(this.pixels, this.mw, this.mh, m.x, m.y, tol);
		const soft = this.brush.softness / 100;
		if (soft > .04) temp = boxBlur(temp, this.mw, this.mh, Math.max(1, Math.round(soft * 8)), 1);
		compositeMax(rec.mask, temp, this.brush.additive, this.brush.strength / 100);
		this.markMask();
	}
	commitShape(points) {
		const rec = this.activeRec();
		this.polyImage = [];
		if (!rec || points.length < 3) return;
		this.pushHistory(rec);
		let temp = fillPolygon(points.map((point) => this.toMask(point.x, point.y)), this.mw, this.mh);
		const soft = this.brush.softness / 100;
		if (soft > .02) temp = boxBlur(temp, this.mw, this.mh, Math.max(1, Math.round(soft * 12)), 2);
		const add = this.tool === "eraser" ? false : this.brush.additive;
		compositeMax(rec.mask, temp, add, this.brush.strength / 100);
		this.markMask();
	}
	pushHistory(rec) {
		this.undoStack.push({
			id: rec.meta.id,
			mask: rec.mask.slice(),
			freeze: rec.freeze.slice()
		});
		if (this.undoStack.length > 30) this.undoStack.shift();
		this.redoStack = [];
	}
	markMask() {
		this.weightsDirty = true;
		this.overlayDirty = true;
		this.refreshSelection();
		this.emit();
	}
	refreshSelection() {
		let any = false;
		for (const rec of this.regions.values()) if (rec.meta.visible && maskHasInk(rec.mask)) {
			any = true;
			break;
		}
		this.hasSelection = any;
	}
	activeRec() {
		if (!this.activeId) return void 0;
		return this.regions.get(this.activeId);
	}
	hitRegion(ix, iy) {
		if (!this.mw || !this.workW) return -1;
		const mx = clamp(Math.round(ix / this.workW * (this.mw - 1)), 0, this.mw - 1);
		const index = clamp(Math.round(iy / this.workH * (this.mh - 1)), 0, this.mh - 1) * this.mw + mx;
		const active = this.order.indexOf(this.activeId ?? "");
		if (active >= 0) {
			const rec = this.regions.get(this.order[active]);
			if (rec?.meta.visible && (rec.mask[index] ?? 0) > 16) return active;
		}
		let best = -1;
		let bestV = 16;
		this.order.forEach((id, regionIndex) => {
			const rec = this.regions.get(id);
			if (!rec?.meta.visible) return;
			const value = rec.mask[index] ?? 0;
			if (value > bestV) {
				bestV = value;
				best = regionIndex;
			}
		});
		return best;
	}
	rebuildSim() {
		if (!this.workW) return;
		const q = this.quality / 100;
		let cols = Math.round(lerp(16, 56, q));
		let rows = Math.max(10, Math.round(cols * (this.workH / this.workW)));
		while ((cols + 1) * (rows + 1) > 6800 && cols > 14) {
			cols -= 2;
			rows = Math.max(8, Math.round(cols * (this.workH / this.workW)));
		}
		this.sim = new SoftBody(cols, rows, this.workW, this.workH);
		const n = this.sim.count;
		this.pos = new Float32Array(n * 2);
		this.uv = new Float32Array(n * 2);
		this.wBuf = new Float32Array(n);
		this.rBuf = new Int16Array(n);
		this.fBuf = new Uint8Array(n);
		const nx = cols + 1;
		for (let r = 0; r <= rows; r++) for (let c = 0; c <= cols; c++) {
			const i = r * nx + c;
			this.uv[i * 2] = c / cols;
			this.uv[i * 2 + 1] = 1 - r / rows;
		}
		const tris = [];
		const lines = [];
		for (let r = 0; r < rows; r++) for (let c = 0; c < cols; c++) {
			const i = r * nx + c;
			tris.push(i, i + 1, i + nx, i + 1, i + nx + 1, i + nx);
			lines.push(i, i + 1, i, i + nx);
		}
		for (let c = 0; c < cols; c++) lines.push(rows * nx + c, rows * nx + c + 1);
		for (let r = 0; r < rows; r++) lines.push(r * nx + cols, (r + 1) * nx + cols);
		this.indices = new Uint16Array(tris);
		this.lineIdx = new Uint16Array(lines);
		this.triCount = tris.length;
		this.weightsDirty = true;
		this.uploadStaticMesh(this.pipe);
		if (this.exportPipe && this.workCanvas) this.uploadImageTo(this.exportPipe, this.workCanvas);
	}
	resample() {
		const sim = this.sim;
		if (!sim) return;
		this.weightsDirty = false;
		const params = [];
		this.order.forEach((id) => {
			const rec = this.regions.get(id);
			if (rec) params.push(rec.meta.params);
		});
		const nx = sim.cols + 1;
		for (let r = 0; r <= sim.rows; r++) for (let c = 0; c <= sim.cols; c++) {
			const i = r * nx + c;
			const u = c / sim.cols;
			const v = r / sim.rows;
			let best = 0;
			let bestRegion = -1;
			let freeze = 0;
			for (let region = 0; region < this.order.length; region++) {
				const rec = this.regions.get(this.order[region]);
				if (!rec?.meta.visible) continue;
				const value = this.sampleMask(rec.mask, u, v);
				if (value > best) {
					best = value;
					bestRegion = region;
					freeze = this.sampleMask(rec.freeze, u, v);
				}
			}
			this.wBuf[i] = bestRegion < 0 ? 0 : smoothstep(.06, .5, best);
			this.rBuf[i] = bestRegion;
			this.fBuf[i] = freeze > .45 ? 1 : 0;
		}
		sim.setMaps(this.wBuf, this.rBuf, this.fBuf, params);
	}
	sampleMask(mask, u, v) {
		if (!this.mw || mask.length !== this.mw * this.mh) return 0;
		const x = clamp(u, 0, 1) * (this.mw - 1);
		const y = clamp(v, 0, 1) * (this.mh - 1);
		const x0 = Math.floor(x);
		const y0 = Math.floor(y);
		const x1 = Math.min(this.mw - 1, x0 + 1);
		const y1 = Math.min(this.mh - 1, y0 + 1);
		const tx = x - x0;
		const ty = y - y0;
		const at = (px, py) => mask[py * this.mw + px] ?? 0;
		const a = at(x0, y0) + (at(x1, y0) - at(x0, y0)) * tx;
		return (a + (at(x0, y1) + (at(x1, y1) - at(x0, y1)) * tx - a) * ty) / 255;
	}
	uploadImage(canvas) {
		if (!this.pipe) return;
		this.uploadImageTo(this.pipe, canvas);
		if (this.exportPipe) this.uploadImageTo(this.exportPipe, canvas);
	}
	uploadImageTo(pipe, canvas) {
		const gl = pipe.gl;
		gl.bindTexture(gl.TEXTURE_2D, pipe.image);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, gl.RGBA, gl.UNSIGNED_BYTE, canvas);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MIN_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_MAG_FILTER, gl.LINEAR);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_S, gl.CLAMP_TO_EDGE);
		gl.texParameteri(gl.TEXTURE_2D, gl.TEXTURE_WRAP_T, gl.CLAMP_TO_EDGE);
	}
	uploadStaticMesh(pipe) {
		if (!pipe) return;
		const gl = pipe.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, pipe.uv);
		gl.bufferData(gl.ARRAY_BUFFER, this.uv, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, pipe.idx);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.indices, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, pipe.lines);
		gl.bufferData(gl.ELEMENT_ARRAY_BUFFER, this.lineIdx, gl.STATIC_DRAW);
		gl.bindBuffer(gl.ARRAY_BUFFER, pipe.pos);
		gl.bufferData(gl.ARRAY_BUFFER, this.pos, gl.DYNAMIC_DRAW);
	}
	uploadMesh(pipe, sx = 1, sy = 1) {
		this.uploadStaticMesh(pipe);
		this.writePositions(sx, sy);
		const gl = pipe.gl;
		gl.bindBuffer(gl.ARRAY_BUFFER, pipe.pos);
		gl.bufferData(gl.ARRAY_BUFFER, this.pos, gl.DYNAMIC_DRAW);
	}
	writePositions(sx = 1, sy = 1) {
		const sim = this.sim;
		if (!sim) return;
		for (let i = 0; i < sim.count; i++) {
			this.pos[i * 2] = sim.x[i] * sx;
			this.pos[i * 2 + 1] = sim.y[i] * sy;
		}
	}
	rebuildOverlayTexture() {
		if (!this.pipe || !this.mw) return;
		const n = this.mw * this.mh;
		if (this.overlayPixels.length !== n * 4) this.overlayPixels = new Uint8Array(n * 4);
		const out = this.overlayPixels;
		out.fill(0);
		const opacity = this.brush.opacity / 100;
		for (let i = 0; i < n; i++) {
			let best = 0;
			let rgb = [
				255,
				122,
				69
			];
			for (const id of this.order) {
				const rec = this.regions.get(id);
				if (!rec?.meta.visible) continue;
				const value = rec.mask[i] ?? 0;
				if (value > best) {
					best = value;
					rgb = hexToRgb(rec.meta.color);
				}
			}
			const o = i * 4;
			out[o] = rgb[0];
			out[o + 1] = rgb[1];
			out[o + 2] = rgb[2];
			out[o + 3] = Math.min(255, best * opacity);
		}
		const gl = this.pipe.gl;
		gl.bindTexture(gl.TEXTURE_2D, this.pipe.mask);
		gl.pixelStorei(gl.UNPACK_FLIP_Y_WEBGL, true);
		gl.texImage2D(gl.TEXTURE_2D, 0, gl.RGBA, this.mw, this.mh, 0, gl.RGBA, gl.UNSIGNED_BYTE, out);
		this.overlayDirty = false;
	}
	render() {
		if (this.overlayDirty && this.imageReady) this.rebuildOverlayTexture();
		if (this.sim && this.pipe) {
			this.writePositions();
			const gl = this.pipe.gl;
			gl.bindBuffer(gl.ARRAY_BUFFER, this.pipe.pos);
			gl.bufferSubData(gl.ARRAY_BUFFER, 0, this.pos);
			this.draw(this.pipe, this.originX, this.originY, this.zoom, this.canvas.clientWidth, this.canvas.clientHeight, this.canvas.width, this.canvas.height, this.overlay);
		} else if (this.pipe) {
			const gl = this.pipe.gl;
			gl.viewport(0, 0, this.canvas.width, this.canvas.height);
			gl.clearColor(.047, .055, .071, 1);
			gl.clear(gl.COLOR_BUFFER_BIT);
		}
		this.drawOverlay();
	}
	draw(pipe, originX, originY, zoom, viewW, viewH, bufferW, bufferH, overlayOn) {
		const gl = pipe.gl;
		gl.viewport(0, 0, bufferW, bufferH);
		gl.clearColor(.047, .055, .071, 1);
		gl.clear(gl.COLOR_BUFFER_BIT);
		if (!this.triCount) return;
		gl.useProgram(pipe.program);
		gl.bindBuffer(gl.ARRAY_BUFFER, pipe.pos);
		gl.enableVertexAttribArray(pipe.aPos);
		gl.vertexAttribPointer(pipe.aPos, 2, gl.FLOAT, false, 0, 0);
		gl.bindBuffer(gl.ARRAY_BUFFER, pipe.uv);
		gl.enableVertexAttribArray(pipe.aUV);
		gl.vertexAttribPointer(pipe.aUV, 2, gl.FLOAT, false, 0, 0);
		gl.uniform2f(pipe.uOrigin, originX, originY);
		gl.uniform1f(pipe.uZoom, zoom);
		gl.uniform2f(pipe.uView, Math.max(1, viewW), Math.max(1, viewH));
		gl.uniform1f(pipe.uOverlay, overlayOn ? 1 : 0);
		gl.activeTexture(gl.TEXTURE0);
		gl.bindTexture(gl.TEXTURE_2D, pipe.image);
		gl.uniform1i(pipe.uImage, 0);
		gl.activeTexture(gl.TEXTURE1);
		gl.bindTexture(gl.TEXTURE_2D, pipe.mask);
		gl.uniform1i(pipe.uMask, 1);
		gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, pipe.idx);
		gl.drawElements(gl.TRIANGLES, this.triCount, gl.UNSIGNED_SHORT, 0);
		if (this.showMesh) {
			gl.enable(gl.BLEND);
			gl.blendFunc(gl.SRC_ALPHA, gl.ONE_MINUS_SRC_ALPHA);
			gl.useProgram(pipe.wire);
			gl.bindBuffer(gl.ARRAY_BUFFER, pipe.pos);
			gl.enableVertexAttribArray(0);
			gl.vertexAttribPointer(0, 2, gl.FLOAT, false, 0, 0);
			gl.uniform2f(pipe.wOrigin, originX, originY);
			gl.uniform1f(pipe.wZoom, zoom);
			gl.uniform2f(pipe.wView, Math.max(1, viewW), Math.max(1, viewH));
			gl.uniform4f(pipe.wColor, .24, .88, .69, .35);
			gl.bindBuffer(gl.ELEMENT_ARRAY_BUFFER, pipe.lines);
			gl.drawElements(gl.LINES, this.lineIdx.length, gl.UNSIGNED_SHORT, 0);
			gl.disable(gl.BLEND);
		}
	}
	drawOverlay() {
		const ctx = this.octx;
		if (!ctx) return;
		ctx.clearRect(0, 0, this.overlayCanvas.width, this.overlayCanvas.height);
		if (!this.imageReady) return;
		const dpr = this.dpr;
		if (this.polyImage.length) {
			ctx.setTransform(this.zoom * dpr, 0, 0, this.zoom * dpr, -this.originX * this.zoom * dpr, -this.originY * this.zoom * dpr);
			ctx.beginPath();
			this.polyImage.forEach((point, index) => {
				if (index) ctx.lineTo(point.x, point.y);
				else ctx.moveTo(point.x, point.y);
			});
			ctx.strokeStyle = "#ff7a45";
			ctx.lineWidth = 1.5 / this.zoom;
			ctx.stroke();
			for (const point of this.polyImage) {
				ctx.beginPath();
				ctx.arc(point.x, point.y, 3.5 / this.zoom, 0, Math.PI * 2);
				ctx.fillStyle = "#ff7a45";
				ctx.fill();
			}
		}
		if (this.cursor && this.brushVisible()) {
			ctx.setTransform(dpr, 0, 0, dpr, 0, 0);
			ctx.beginPath();
			ctx.arc(this.cursor.x, this.cursor.y, this.brush.size / 2, 0, Math.PI * 2);
			ctx.strokeStyle = "rgba(244,245,247,0.92)";
			ctx.lineWidth = 1.5;
			ctx.stroke();
		}
	}
	brushVisible() {
		return this.tool === "soft" || this.tool === "hard" || this.tool === "eraser" || this.tool === "smooth" || this.tool === "freeze" || this.tool === "jiggle" || this.tool === "push" || this.tool === "pull" || this.tool === "restore";
	}
	emit() {
		if (this.emitQueued) return;
		this.emitQueued = true;
		requestAnimationFrame(() => {
			this.emitQueued = false;
			if (this.disposed) return;
			this.onChange?.(this.status());
		});
	}
	status() {
		return {
			hasImage: this.imageReady,
			canUndo: this.undoStack.length > 0,
			canRedo: this.redoStack.length > 0,
			hasSelection: this.hasSelection,
			zoom: this.zoom,
			width: this.naturalW,
			height: this.naturalH
		};
	}
};
function p(elasticity, stiffness, damping, mass, gravity, bounce, deform, maxDisp, recovery) {
	return {
		elasticity,
		stiffness,
		damping,
		mass,
		gravity,
		bounce,
		deform,
		maxDisp,
		recovery
	};
}
var PRESETS = [
	{
		id: "jelly",
		name: "Jelly",
		blurb: "Soft, exaggerated wobble",
		params: p(88, 32, 22, 28, 12, 74, 86, 72, 38)
	},
	{
		id: "rubber",
		name: "Rubber",
		blurb: "Elastic and springy",
		params: p(72, 78, 38, 36, 4, 58, 52, 46, 74)
	},
	{
		id: "water",
		name: "Water",
		blurb: "Fluid, heavy slosh",
		params: p(36, 14, 58, 62, 48, 28, 92, 84, 22)
	},
	{
		id: "balloon",
		name: "Balloon",
		blurb: "Light and bouncy",
		params: p(92, 22, 16, 12, 2, 88, 70, 64, 34)
	},
	{
		id: "gelatin",
		name: "Gelatin",
		blurb: "Very soft, slow oscillations",
		params: p(64, 24, 12, 58, 22, 42, 78, 60, 18)
	},
	{
		id: "squishy",
		name: "Squishy",
		blurb: "Deep squash, quick return",
		params: p(76, 28, 48, 22, 8, 64, 96, 88, 84)
	},
	{
		id: "soft",
		name: "Soft body",
		blurb: "Balanced elasticity",
		params: p(66, 54, 46, 42, 10, 48, 62, 52, 56)
	},
	{
		id: "heavy",
		name: "Heavy",
		blurb: "Slow, weighty movement",
		params: p(38, 68, 70, 94, 36, 22, 40, 34, 28)
	},
	{
		id: "subtle",
		name: "Subtle",
		blurb: "Small, gentle motion",
		params: p(48, 62, 72, 40, 0, 18, 24, 18, 68)
	},
	{
		id: "extreme",
		name: "Extreme",
		blurb: "Highly exaggerated",
		params: p(97, 12, 8, 18, 18, 100, 100, 100, 26)
	}
];
function presetById(id) {
	return PRESETS.find((preset) => preset.id === id) ?? PRESETS[6];
}
function cloneParams(params) {
	return { ...params };
}
var PRESET_KEY = "wobble-presets-v1";
var DB_NAME = "wobble";
var STORE = "kv";
function loadCustomPresets() {
	if (typeof localStorage === "undefined") return [];
	try {
		const raw = localStorage.getItem(PRESET_KEY);
		if (!raw) return [];
		const parsed = JSON.parse(raw);
		if (!Array.isArray(parsed)) return [];
		return parsed.filter((item) => item && typeof item.id === "string" && item.params);
	} catch {
		return [];
	}
}
function saveCustomPresets(list) {
	localStorage.setItem(PRESET_KEY, JSON.stringify(list));
}
function openDb() {
	return new Promise((resolve, reject) => {
		const req = indexedDB.open(DB_NAME, 1);
		req.onupgradeneeded = () => {
			if (!req.result.objectStoreNames.contains(STORE)) req.result.createObjectStore(STORE);
		};
		req.onsuccess = () => resolve(req.result);
		req.onerror = () => reject(req.error);
	});
}
async function saveSession(project) {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).put(project, "session");
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
async function loadSession() {
	const db = await openDb();
	const value = await new Promise((resolve, reject) => {
		const req = db.transaction(STORE, "readonly").objectStore(STORE).get("session");
		req.onsuccess = () => resolve(req.result ?? null);
		req.onerror = () => reject(req.error);
	});
	db.close();
	if (!value || value.app !== "wobble" || value.version !== 1) return null;
	return value;
}
async function clearSession() {
	const db = await openDb();
	await new Promise((resolve, reject) => {
		const tx = db.transaction(STORE, "readwrite");
		tx.objectStore(STORE).delete("session");
		tx.oncomplete = () => resolve();
		tx.onerror = () => reject(tx.error);
	});
	db.close();
}
var emptyStatus = {
	hasImage: false,
	canUndo: false,
	canRedo: false,
	hasSelection: false,
	zoom: 1,
	width: 0,
	height: 0
};
function makeRegion(n, params, name) {
	return {
		id: crypto.randomUUID(),
		name: name ?? `Region ${n}`,
		color: REGION_COLORS[(n - 1) % REGION_COLORS.length],
		visible: true,
		params: cloneParams(params)
	};
}
function downloadBlob(blob, filename) {
	const url = URL.createObjectURL(blob);
	const link = document.createElement("a");
	link.href = url;
	link.download = filename;
	link.click();
	URL.revokeObjectURL(url);
}
function Editor() {
	const canvasRef = (0, import_react.useRef)(null);
	const overlayRef = (0, import_react.useRef)(null);
	const engineRef = (0, import_react.useRef)(null);
	const fileRef = (0, import_react.useRef)(null);
	const projectRef = (0, import_react.useRef)(null);
	const apiRef = (0, import_react.useRef)({
		loadSample: async () => {},
		exercise: () => null,
		debug: () => null
	});
	const [tool, setTool] = (0, import_react.useState)("soft");
	const [brush, setBrush] = (0, import_react.useState)(defaultBrush);
	const [regions, setRegions] = (0, import_react.useState)([]);
	const [activeId, setActiveId] = (0, import_react.useState)(null);
	const [status, setStatus] = (0, import_react.useState)(emptyStatus);
	const [imageOn, setImageOn] = (0, import_react.useState)(false);
	const [quality, setQuality] = (0, import_react.useState)(46);
	const [shake, setShake] = (0, import_react.useState)(55);
	const [overlay, setOverlay] = (0, import_react.useState)(true);
	const [showMesh, setShowMesh] = (0, import_react.useState)(false);
	const [paused, setPaused] = (0, import_react.useState)(false);
	const [presetId, setPresetId] = (0, import_react.useState)("jelly");
	const [custom, setCustom] = (0, import_react.useState)([]);
	const [presetName, setPresetName] = (0, import_react.useState)("");
	const [sheet, setSheet] = (0, import_react.useState)(null);
	const [exportOpen, setExportOpen] = (0, import_react.useState)(false);
	const [confirmReset, setConfirmReset] = (0, import_react.useState)(false);
	const [busy, setBusy] = (0, import_react.useState)(null);
	const [hasSession, setHasSession] = (0, import_react.useState)(false);
	const [motion, setMotion] = (0, import_react.useState)("off");
	const [leftW, setLeftW] = (0, import_react.useState)(240);
	const [rightW, setRightW] = (0, import_react.useState)(300);
	const [dragOver, setDragOver] = (0, import_react.useState)(false);
	const active = regions.find((region) => region.id === activeId) ?? null;
	const mode = toolMode(tool);
	(0, import_react.useEffect)(() => {
		const canvas = canvasRef.current;
		const overlayCanvas = overlayRef.current;
		if (!canvas || !overlayCanvas) return;
		const engine = new JiggleEngine(canvas, overlayCanvas);
		engineRef.current = engine;
		engine.tool = tool;
		engine.brush = brush;
		engine.overlay = overlay;
		engine.showMesh = showMesh;
		engine.paused = paused;
		engine.shakeSensitivity = shake;
		engine.onChange = (next) => setStatus(next);
		engine.onProject = (project, metas) => {
			setRegions(metas);
			setActiveId(project.activeId && metas.some((region) => region.id === project.activeId) ? project.activeId : metas[0]?.id ?? null);
			setQuality(project.quality || 46);
			setShake(project.shake ?? 55);
			setOverlay(project.overlay !== false);
			setBrush((current) => ({
				...current,
				opacity: project.opacity ?? current.opacity
			}));
			setImageOn(true);
			setTool("interact");
		};
		window.__wobble = {
			loadSample: () => apiRef.current.loadSample(),
			exercise: () => engine.exercise(),
			debug: () => engine.debug()
		};
		setCustom(loadCustomPresets());
		loadSession().then((project) => setHasSession(Boolean(project))).catch(() => setHasSession(false));
		return () => {
			engine.destroy();
			if (engineRef.current === engine) engineRef.current = null;
		};
	}, []);
	(0, import_react.useEffect)(() => {
		engineRef.current?.syncRegions(regions, activeId);
	}, [regions, activeId]);
	(0, import_react.useEffect)(() => {
		const engine = engineRef.current;
		if (!engine) return;
		engine.tool = tool;
		if (tool !== "polygon" && tool !== "lasso") engine.cancelShape();
	}, [tool]);
	(0, import_react.useEffect)(() => {
		engineRef.current?.setBrush(brush);
	}, [brush]);
	(0, import_react.useEffect)(() => {
		engineRef.current?.setQuality(quality);
	}, [quality]);
	(0, import_react.useEffect)(() => {
		const engine = engineRef.current;
		if (!engine) return;
		engine.overlay = overlay;
		engine.showMesh = showMesh;
		engine.paused = paused;
		engine.shakeSensitivity = shake;
	}, [
		overlay,
		showMesh,
		paused,
		shake
	]);
	(0, import_react.useEffect)(() => {
		if (!imageOn) return;
		const handle = window.setTimeout(() => {
			const engine = engineRef.current;
			if (!engine) return;
			engine.toProject({
				quality,
				shake,
				opacity: brush.opacity,
				overlay
			}).then((project) => {
				if (project.image.length > 14e6) return;
				return saveSession(project);
			}).then(() => setHasSession(true)).catch(() => void 0);
		}, 1200);
		return () => window.clearTimeout(handle);
	}, [
		imageOn,
		regions,
		activeId,
		quality,
		shake,
		overlay,
		brush.opacity,
		status.canUndo
	]);
	(0, import_react.useEffect)(() => {
		function onKey(event) {
			const target = event.target;
			if (target && (target.tagName === "INPUT" || target.tagName === "TEXTAREA" || target.isContentEditable)) return;
			const engine = engineRef.current;
			if (!engine) return;
			if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "z") {
				event.preventDefault();
				if (event.shiftKey) engine.redo();
				else engine.undo();
				return;
			}
			if ((event.metaKey || event.ctrlKey) && event.key.toLowerCase() === "y") {
				event.preventDefault();
				engine.redo();
				return;
			}
			if (event.code === "Space") {
				event.preventDefault();
				engine.space = true;
				return;
			}
			if (event.key === "Enter") engine.closePolygon();
			if (event.key === "Escape") {
				engine.cancelShape();
				setSheet(null);
				setExportOpen(false);
			}
			if (event.key === "[") setBrush((current) => ({
				...current,
				size: Math.max(8, current.size - 8)
			}));
			if (event.key === "]") setBrush((current) => ({
				...current,
				size: Math.min(220, current.size + 8)
			}));
			if (event.key === "0") engine.fit();
			if (event.metaKey || event.ctrlKey || event.altKey) return;
			const next = {
				b: "soft",
				n: "hard",
				e: "eraser",
				p: "polygon",
				l: "lasso",
				g: "fill",
				h: "pan",
				v: "interact",
				j: "jiggle",
				u: "push",
				i: "pull",
				m: "smooth",
				f: "freeze",
				r: "restore"
			}[event.key.toLowerCase()];
			if (next) setTool(next);
		}
		function onKeyUp(event) {
			if (event.code === "Space" && engineRef.current) engineRef.current.space = false;
		}
		window.addEventListener("keydown", onKey);
		window.addEventListener("keyup", onKeyUp);
		return () => {
			window.removeEventListener("keydown", onKey);
			window.removeEventListener("keyup", onKeyUp);
		};
	}, []);
	async function openFile(file) {
		if (!file.type.startsWith("image/")) {
			toast.error("Use a PNG, JPG, or WebP image");
			return;
		}
		const engine = engineRef.current;
		if (!engine) return;
		setBusy("Opening image…");
		try {
			await engine.loadFile(file);
			const region = makeRegion(1, presetById("jelly").params);
			engine.syncRegions([region], region.id);
			setRegions([region]);
			setActiveId(region.id);
			setPresetId("jelly");
			setTool("soft");
			setImageOn(true);
			setSheet(null);
			toast.success("Paint a region, then switch to Play");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not open that image");
		} finally {
			setBusy(null);
		}
	}
	async function openSample() {
		const engine = engineRef.current;
		if (!engine) return;
		setBusy("Loading sample…");
		try {
			await engine.loadDataUrl(gummy_default);
			const region = makeRegion(1, presetById("jelly").params, "Gummy");
			engine.syncRegions([region], region.id);
			engine.selectWarmSubject();
			setRegions([region]);
			setActiveId(region.id);
			setPresetId("jelly");
			setTool("interact");
			setImageOn(true);
			setSheet(null);
			toast.success("Drag the gummy, tap it, or press Shake");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not load the sample");
		} finally {
			setBusy(null);
		}
	}
	apiRef.current = {
		loadSample: openSample,
		exercise: () => engineRef.current?.exercise() ?? null,
		debug: () => engineRef.current?.debug() ?? null
	};
	async function openProjectFile(file) {
		const engine = engineRef.current;
		if (!engine) return;
		setBusy("Opening project…");
		try {
			const project = JSON.parse(await file.text());
			await engine.ingestProject(project);
			toast.success("Project loaded");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not open that project");
		} finally {
			setBusy(null);
		}
	}
	async function restoreSession() {
		const engine = engineRef.current;
		if (!engine) return;
		setBusy("Restoring session…");
		try {
			const project = await loadSession();
			if (!project) {
				toast.error("No saved session");
				setHasSession(false);
				return;
			}
			await engine.ingestProject(project);
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not restore the session");
		} finally {
			setBusy(null);
		}
	}
	async function doReset() {
		engineRef.current?.clearImage();
		setRegions([]);
		setActiveId(null);
		setImageOn(false);
		setStatus(emptyStatus);
		setTool("soft");
		setConfirmReset(false);
		try {
			await clearSession();
		} catch {}
		setHasSession(false);
	}
	function patchRegion(id, partial) {
		setRegions((current) => current.map((region) => region.id === id ? {
			...region,
			...partial
		} : region));
	}
	function patchParams(partial) {
		if (!activeId) return;
		setPresetId("");
		setRegions((current) => current.map((region) => region.id === activeId ? {
			...region,
			params: {
				...region.params,
				...partial
			}
		} : region));
	}
	function addRegion() {
		const region = makeRegion(regions.length + 1, active?.params ?? presetById("jelly").params);
		const next = [...regions, region];
		setRegions(next);
		setActiveId(region.id);
		setTool("soft");
	}
	function deleteRegion(id) {
		const next = regions.filter((region) => region.id !== id);
		setRegions(next);
		setActiveId((current) => current === id ? next[0]?.id ?? null : current);
	}
	async function exportPNG() {
		const engine = engineRef.current;
		if (!engine) return;
		setBusy("Exporting PNG…");
		setExportOpen(false);
		try {
			downloadBlob(await engine.exportPNG(), "wobble.png");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Export failed");
		} finally {
			setBusy(null);
		}
	}
	async function exportVideo() {
		const engine = engineRef.current;
		if (!engine) return;
		setExportOpen(false);
		setBusy("Recording video…");
		try {
			downloadBlob(await engine.exportVideo(3), "wobble.webm");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Video export is not supported here");
		} finally {
			setBusy(null);
		}
	}
	async function exportGIF() {
		const engine = engineRef.current;
		if (!engine) return;
		setExportOpen(false);
		setBusy("Encoding GIF…");
		try {
			downloadBlob(await engine.exportGIF(2), "wobble.gif");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "GIF export failed");
		} finally {
			setBusy(null);
		}
	}
	async function saveProject() {
		const engine = engineRef.current;
		if (!engine) return;
		setExportOpen(false);
		setBusy("Saving project…");
		try {
			const project = await engine.toProject({
				quality,
				shake,
				opacity: brush.opacity,
				overlay
			});
			downloadBlob(new Blob([JSON.stringify(project)], { type: "application/json" }), "wobble-project.json");
		} catch (error) {
			toast.error(error instanceof Error ? error.message : "Could not save the project");
		} finally {
			setBusy(null);
		}
	}
	async function enableMotion() {
		try {
			const motionEvent = DeviceMotionEvent;
			if (typeof motionEvent.requestPermission === "function") {
				if (await motionEvent.requestPermission() !== "granted") {
					setMotion("denied");
					toast.error("Motion permission was denied. Use the Shake button instead.");
					return;
				}
			}
			const damp = {
				x: 0,
				y: 0
			};
			const onMotion = (event) => {
				let ax = event.acceleration?.x;
				let ay = event.acceleration?.y;
				if (ax == null || ay == null) {
					const gravity = event.accelerationIncludingGravity;
					if (gravity?.x == null || gravity.y == null) return;
					damp.x = damp.x * .9 + gravity.x * .1;
					damp.y = damp.y * .9 + gravity.y * .1;
					ax = gravity.x - damp.x;
					ay = gravity.y - damp.y;
				}
				engineRef.current?.applyMotion(ax, ay);
			};
			window.addEventListener("devicemotion", onMotion);
			setMotion("on");
			toast.success("Motion sensors on. Shake the phone to wobble the selection.");
		} catch {
			setMotion("denied");
			toast.error("This browser has no motion sensor. Use the Shake button.");
		}
	}
	function saveCustom() {
		if (!active || !presetName.trim()) return;
		const next = [...custom, {
			id: crypto.randomUUID(),
			name: presetName.trim(),
			params: cloneParams(active.params)
		}];
		setCustom(next);
		saveCustomPresets(next);
		setPresetName("");
		toast.success("Preset saved on this device");
	}
	const toolsPane = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
				className: "grid grid-cols-2 rounded-lg bg-surface-2 p-1",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("h-10 rounded-md text-sm font-medium", mode === "select" ? "bg-surface-3 text-fg" : "text-muted"),
					onClick: () => setTool(mode === "select" ? tool : "soft"),
					children: "Select"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
					type: "button",
					className: cn("h-10 rounded-md text-sm font-medium", mode === "play" ? "bg-accent text-accent-ink" : "text-muted"),
					onClick: () => setTool("interact"),
					children: "Play"
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium text-muted",
					children: "Selection"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brush, { className: "size-4" }),
							label: "Soft",
							shortcut: "B",
							active: tool === "soft",
							onClick: () => setTool("soft")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PenLine, { className: "size-4" }),
							label: "Hard",
							shortcut: "N",
							active: tool === "hard",
							onClick: () => setTool("hard")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eraser, { className: "size-4" }),
							label: "Eraser",
							shortcut: "E",
							active: tool === "eraser",
							onClick: () => setTool("eraser")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pentagon, { className: "size-4" }),
							label: "Polygon",
							shortcut: "P",
							active: tool === "polygon",
							onClick: () => setTool("polygon")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Lasso, { className: "size-4" }),
							label: "Lasso",
							shortcut: "L",
							active: tool === "lasso",
							onClick: () => setTool("lasso")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(PaintBucket, { className: "size-4" }),
							label: "Fill",
							shortcut: "G",
							active: tool === "fill",
							onClick: () => setTool("fill")
						})
					]
				})]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium text-muted",
						children: "Brush"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Size",
						value: brush.size,
						min: 8,
						max: 220,
						onChange: (size) => setBrush({
							...brush,
							size
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Strength",
						value: brush.strength,
						onChange: (strength) => setBrush({
							...brush,
							strength
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Edge softness",
						value: brush.softness,
						onChange: (softness) => setBrush({
							...brush,
							softness
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Overlay opacity",
						value: brush.opacity,
						onChange: (opacity) => setBrush({
							...brush,
							opacity
						})
					}),
					tool === "fill" && /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Fill tolerance",
						value: brush.tolerance,
						onChange: (tolerance) => setBrush({
							...brush,
							tolerance
						})
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "grid grid-cols-2 gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("h-10 rounded-md text-sm", brush.additive ? "bg-accent text-accent-ink" : "bg-surface-2 text-muted"),
							onClick: () => setBrush({
								...brush,
								additive: true
							}),
							children: "Add"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: cn("h-10 rounded-md text-sm", !brush.additive ? "bg-accent text-accent-ink" : "bg-surface-2 text-muted"),
							onClick: () => setBrush({
								...brush,
								additive: false
							}),
							children: "Subtract"
						})]
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-xs leading-relaxed text-muted",
						children: tool === "polygon" ? "Click to place points. Click the first point or press Enter to close." : tool === "lasso" ? "Drag a free outline. It fills when you release." : tool === "fill" ? "Fills a patch of similar color. Softness feathers the edge." : "Paint only the parts that should move. Everything else stays rigid."
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
					className: "text-xs font-medium text-muted",
					children: "Sculpt"
				}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "grid grid-cols-2 gap-1.5",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-4" }),
							label: "Jiggle",
							shortcut: "J",
							active: tool === "jiggle",
							onClick: () => setTool("jiggle")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Move, { className: "size-4" }),
							label: "Push",
							shortcut: "U",
							active: tool === "push",
							onClick: () => setTool("push")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Magnet, { className: "size-4" }),
							label: "Pull",
							shortcut: "I",
							active: tool === "pull",
							onClick: () => setTool("pull")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Blend, { className: "size-4" }),
							label: "Smooth",
							shortcut: "M",
							active: tool === "smooth",
							onClick: () => setTool("smooth")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Snowflake, { className: "size-4" }),
							label: "Freeze",
							shortcut: "F",
							active: tool === "freeze",
							onClick: () => setTool("freeze")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCw, { className: "size-4" }),
							label: "Restore",
							shortcut: "R",
							active: tool === "restore",
							onClick: () => setTool("restore")
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(ToolButton, {
							icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Hand, { className: "size-4" }),
							label: "Pan",
							shortcut: "H",
							active: tool === "pan",
							onClick: () => setTool("pan")
						})
					]
				})]
			})
		]
	});
	const physicsPane = /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
		className: "flex flex-col gap-4",
		children: [
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex items-center justify-between",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
							className: "text-xs font-medium text-muted",
							children: "Regions"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex h-8 items-center gap-1 rounded-md px-2 text-xs text-fg hover:bg-surface-3",
							onClick: addRegion,
							disabled: !imageOn,
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Plus, { className: "size-3.5" }), "Add"]
						})]
					}),
					regions.length === 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Load an image to create a region."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1",
						children: regions.map((region) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("li", {
							className: cn("rounded-md px-1.5 py-1", region.id === activeId ? "bg-surface-3" : "hover:bg-surface-2"),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "flex items-center gap-1.5",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
										className: "size-3 shrink-0 rounded-full",
										style: { background: region.color }
									}),
									region.id === activeId ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
										value: region.name,
										"aria-label": "Region name",
										onChange: (event) => patchRegion(region.id, { name: event.target.value }),
										className: "min-w-0 flex-1 bg-transparent text-sm text-fg outline-none"
									}) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "min-w-0 flex-1 truncate text-left text-sm",
										onClick: () => setActiveId(region.id),
										children: region.name
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-8 items-center justify-center rounded-md text-muted hover:text-fg",
										"aria-label": region.visible ? "Hide region" : "Show region",
										onClick: () => patchRegion(region.id, { visible: !region.visible }),
										children: region.visible ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(EyeOff, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-8 items-center justify-center rounded-md text-muted hover:text-fg",
										"aria-label": "Settle region",
										onClick: () => engineRef.current?.resetRegion(region.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
										type: "button",
										className: "inline-flex size-8 items-center justify-center rounded-md text-muted hover:text-danger",
										"aria-label": "Delete region",
										onClick: () => deleteRegion(region.id),
										children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Trash2, { className: "size-4" })
									})
								]
							})
						}, region.id))
					}),
					active && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex flex-wrap gap-1.5",
						children: [REGION_COLORS.map((color) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							"aria-label": `Color ${color}`,
							className: cn("size-6 rounded-full ring-offset-2 ring-offset-surface", active.color === color && "ring-2 ring-fg"),
							style: { background: color },
							onClick: () => patchRegion(active.id, { color })
						}, color)), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-6 rounded-md px-2 text-xs text-muted hover:text-fg",
							onClick: () => engineRef.current?.clearActiveMask(),
							children: "Clear mask"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
						className: "text-xs font-medium text-muted",
						children: "Presets"
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "flex flex-wrap gap-1.5",
						children: PRESETS.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							title: preset.blurb,
							disabled: !active,
							onClick: () => {
								if (!active) return;
								setPresetId(preset.id);
								patchRegion(active.id, { params: cloneParams(preset.params) });
							},
							className: cn("h-8 rounded-full border px-2.5 text-xs disabled:opacity-40", presetId === preset.id ? "border-accent bg-accent text-accent-ink" : "border-border text-fg hover:border-muted"),
							children: preset.name
						}, preset.id))
					}),
					custom.length > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("ul", {
						className: "flex flex-col gap-1",
						children: custom.map((preset) => /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("li", {
							className: "flex items-center gap-1",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "h-8 min-w-0 flex-1 truncate rounded-md px-2 text-left text-sm hover:bg-surface-3",
								onClick: () => {
									if (!active) return;
									setPresetId(preset.id);
									patchRegion(active.id, { params: cloneParams(preset.params) });
								},
								children: preset.name
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								"aria-label": `Delete ${preset.name}`,
								className: "inline-flex size-8 items-center justify-center text-muted hover:text-danger",
								onClick: () => {
									const next = custom.filter((item) => item.id !== preset.id);
									setCustom(next);
									saveCustomPresets(next);
								},
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(X, { className: "size-3.5" })
							})]
						}, preset.id))
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "flex gap-1.5",
						children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
							value: presetName,
							onChange: (event) => setPresetName(event.target.value),
							placeholder: "Custom preset name",
							className: "h-10 min-w-0 flex-1 rounded-md border border-border bg-surface-2 px-2 text-sm text-fg outline-none placeholder:text-muted"
						}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
							type: "button",
							className: "h-10 rounded-md bg-surface-3 px-3 text-sm disabled:opacity-40",
							disabled: !active || !presetName.trim(),
							onClick: saveCustom,
							children: "Save"
						})]
					})
				]
			}),
			/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("section", {
				className: "flex flex-col gap-2",
				children: [
					/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("h2", {
						className: "text-xs font-medium text-muted",
						children: ["Physics ", active ? `· ${active.name}` : ""]
					}),
					active ? /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Elasticity",
							value: active.params.elasticity,
							onChange: (elasticity) => patchParams({ elasticity })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Stiffness",
							value: active.params.stiffness,
							onChange: (stiffness) => patchParams({ stiffness })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Damping",
							value: active.params.damping,
							onChange: (damping) => patchParams({ damping })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Mass",
							value: active.params.mass,
							onChange: (mass) => patchParams({ mass })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Gravity",
							value: active.params.gravity,
							onChange: (gravity) => patchParams({ gravity })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Bounce",
							value: active.params.bounce,
							onChange: (bounce) => patchParams({ bounce })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Deformation",
							value: active.params.deform,
							onChange: (deform) => patchParams({ deform })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Max displacement",
							value: active.params.maxDisp,
							onChange: (maxDisp) => patchParams({ maxDisp })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
							label: "Recovery",
							value: active.params.recovery,
							onChange: (recovery) => patchParams({ recovery })
						})
					] }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
						className: "text-sm text-muted",
						children: "Select a region to tune how it moves."
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Mesh quality",
						value: quality,
						onChange: setQuality
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Field, {
						label: "Shake sensitivity",
						value: shake,
						onChange: setShake
					}),
					/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "h-10 rounded-md bg-surface-3 text-sm disabled:opacity-50",
						onClick: () => void enableMotion(),
						disabled: motion === "on",
						children: motion === "on" ? "Motion sensors on" : motion === "denied" ? "Sensors blocked — use Shake" : "Enable motion sensors"
					})
				]
			})
		]
	});
	const hint = !imageOn ? "Upload an image to begin" : mode === "select" ? "Paint the parts that should jiggle" : status.hasSelection ? "Drag to stretch · tap to bounce · release to settle" : "No selection yet — switch to Select and paint";
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipProvider, {
		delayDuration: 350,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
			className: "flex h-dvh flex-col overflow-hidden bg-bg text-fg",
			children: [
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("header", {
					className: "flex h-12 shrink-0 items-center gap-1 border-b border-border bg-surface px-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "mr-1 flex items-center gap-2",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "grid size-8 place-items-center rounded-lg bg-accent text-accent-ink",
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-4" })
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
								className: "hidden text-sm font-semibold sm:inline",
								children: "Wobble"
							})]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Upload image",
							onClick: () => fileRef.current?.click(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Undo",
							disabled: !status.canUndo,
							onClick: () => engineRef.current?.undo(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Undo2, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Redo",
							disabled: !status.canRedo,
							onClick: () => engineRef.current?.redo(),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Redo2, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "mx-1 hidden items-center sm:flex",
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "grid grid-cols-2 rounded-lg bg-surface-2 p-0.5",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: cn("h-8 rounded-md px-2.5 text-xs font-medium", mode === "select" ? "bg-surface-3 text-fg" : "text-muted"),
									onClick: () => setTool("soft"),
									children: "Select"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: cn("h-8 rounded-md px-2.5 text-xs font-medium", mode === "play" ? "bg-accent text-accent-ink" : "text-muted"),
									onClick: () => setTool("interact"),
									children: "Play"
								})]
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", { className: "flex-1" }),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex h-10 items-center gap-1.5 rounded-md px-2 text-sm lg:hidden",
							onClick: () => setSheet(sheet === "tools" ? null : "tools"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Brush, { className: "size-4" }), "Tools"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "inline-flex h-10 items-center gap-1.5 rounded-md px-2 text-sm lg:hidden",
							onClick: () => setSheet(sheet === "physics" ? null : "physics"),
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SlidersHorizontal, { className: "size-4" }), "Physics"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
							className: "relative",
							children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
								label: "Export and project",
								pressed: exportOpen,
								onClick: () => setExportOpen((open) => !open),
								disabled: !imageOn,
								children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Download, { className: "size-4" })
							}), exportOpen && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(import_jsx_runtime.Fragment, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
								type: "button",
								className: "fixed inset-0 z-20 cursor-default",
								"aria-label": "Close menu",
								onClick: () => setExportOpen(false)
							}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "absolute right-0 z-30 mt-1 w-52 rounded-lg border border-border bg-surface-2 p-1 shadow-xl",
								children: [
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ImagePlus, { className: "size-4" }),
										label: "Export PNG",
										onClick: () => void exportPNG()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Film, { className: "size-4" }),
										label: "Export video",
										onClick: () => void exportVideo()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-4" }),
										label: "Export GIF",
										onClick: () => void exportGIF()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FileJson, { className: "size-4" }),
										label: "Save project",
										onClick: () => void saveProject()
									}),
									/* @__PURE__ */ (0, import_jsx_runtime.jsx)(MenuItem, {
										icon: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(FolderOpen, { className: "size-4" }),
										label: "Open project",
										onClick: () => projectRef.current?.click()
									})
								]
							})] })]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Reset image",
							disabled: !imageOn,
							onClick: () => setConfirmReset(true),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(RotateCcw, { className: "size-4" })
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "flex min-h-0 flex-1",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: "hidden shrink-0 flex-col border-r border-border bg-surface lg:flex",
							style: { width: leftW },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "scroll-thin min-h-0 flex-1 overflow-y-auto p-3",
								children: toolsPane
							})
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden w-1.5 shrink-0 cursor-col-resize bg-border/40 hover:bg-accent lg:block",
							onPointerDown: (event) => {
								event.preventDefault();
								let last = event.clientX;
								const move = (ev) => {
									const dx = ev.clientX - last;
									last = ev.clientX;
									setLeftW((width) => Math.max(200, Math.min(360, width + dx)));
								};
								const up = () => {
									window.removeEventListener("pointermove", move);
									window.removeEventListener("pointerup", up);
								};
								window.addEventListener("pointermove", move);
								window.addEventListener("pointerup", up);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("main", {
							className: cn("relative min-w-0 flex-1", dragOver && "outline outline-2 outline-accent"),
							onDragOver: (event) => {
								event.preventDefault();
								setDragOver(true);
							},
							onDragLeave: () => setDragOver(false),
							onDrop: (event) => {
								event.preventDefault();
								setDragOver(false);
								const file = event.dataTransfer.files[0];
								if (file) {
									if (file.name.endsWith(".json")) openProjectFile(file);
									else openFile(file);
								}
							},
							children: [
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
									ref: canvasRef,
									className: "absolute inset-0 h-full w-full touch-none"
								}),
								/* @__PURE__ */ (0, import_jsx_runtime.jsx)("canvas", {
									ref: overlayRef,
									className: "pointer-events-none absolute inset-0 h-full w-full"
								}),
								imageOn && status.width > 0 && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
									className: "pointer-events-none absolute top-3 left-3 rounded-md bg-surface/90 px-2 py-1 text-xs text-muted",
									children: [
										status.width,
										" × ",
										status.height
									]
								}),
								busy && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute top-3 left-1/2 -translate-x-1/2 rounded-full bg-surface px-3 py-1.5 text-sm text-fg shadow",
									children: busy
								}),
								!imageOn && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
									className: "absolute inset-0 flex items-center justify-center p-4",
									children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
										className: "w-full max-w-md rounded-xl border border-border bg-surface p-6 shadow-xl",
										children: [
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h1", {
												className: "text-2xl font-semibold tracking-tight",
												children: "Make any photo jiggle"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-2 text-sm leading-relaxed text-muted",
												children: "Paint a region, then drag it. Only that part stretches on a spring mesh and settles back. Images stay in the browser."
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
												className: "mt-5 flex flex-wrap gap-2",
												children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													className: "inline-flex h-11 items-center gap-2 rounded-md bg-accent px-4 text-sm font-medium text-accent-ink",
													onClick: () => fileRef.current?.click(),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Upload, { className: "size-4" }), "Upload image"]
												}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
													type: "button",
													className: "inline-flex h-11 items-center gap-2 rounded-md bg-surface-3 px-4 text-sm font-medium",
													onClick: () => void openSample(),
													children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Waves, { className: "size-4" }), "Try the gummy"]
												})]
											}),
											hasSession && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
												type: "button",
												className: "mt-3 text-sm text-mint hover:underline",
												onClick: () => void restoreSession(),
												children: "Restore last session"
											}),
											/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
												className: "mt-4 text-xs text-muted",
												children: "PNG, JPG, JPEG, WebP"
											})
										]
									})
								})
							]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
							className: "hidden w-1.5 shrink-0 cursor-col-resize bg-border/40 hover:bg-accent lg:block",
							onPointerDown: (event) => {
								event.preventDefault();
								let last = event.clientX;
								const move = (ev) => {
									const dx = ev.clientX - last;
									last = ev.clientX;
									setRightW((width) => Math.max(240, Math.min(420, width - dx)));
								};
								const up = () => {
									window.removeEventListener("pointermove", move);
									window.removeEventListener("pointerup", up);
								};
								window.addEventListener("pointermove", move);
								window.addEventListener("pointerup", up);
							}
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("aside", {
							className: "hidden shrink-0 flex-col border-l border-border bg-surface lg:flex",
							style: { width: rightW },
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
								className: "scroll-thin min-h-0 flex-1 overflow-y-auto p-3",
								children: physicsPane
							})
						})
					]
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("footer", {
					className: "flex h-12 shrink-0 items-center gap-1 border-t border-border bg-surface px-2",
					children: [
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: paused ? "Resume simulation" : "Pause simulation",
							pressed: paused,
							onClick: () => setPaused((value) => !value),
							children: paused ? /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Play, { className: "size-4" }) : /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Pause, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Shake selection",
							disabled: !imageOn,
							onClick: () => engineRef.current?.shake(1),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Vibrate, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: overlay ? "Hide selection overlay" : "Show selection overlay",
							pressed: overlay,
							onClick: () => setOverlay((value) => !value),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Eye, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: showMesh ? "Hide mesh" : "Show mesh",
							pressed: showMesh,
							onClick: () => setShowMesh((value) => !value),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Scan, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Zoom out",
							onClick: () => engineRef.current?.zoomBy(1 / 1.15),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomOut, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
							type: "button",
							className: "h-10 min-w-14 rounded-md px-2 text-xs tabular-nums text-muted hover:bg-surface-3",
							onClick: () => engineRef.current?.fit(),
							children: [Math.round((status.zoom || 1) * 100), "%"]
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)(IconButton, {
							label: "Zoom in",
							onClick: () => engineRef.current?.zoomBy(1.15),
							children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(ZoomIn, { className: "size-4" })
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
							className: "ml-2 hidden min-w-0 flex-1 truncate text-xs text-muted md:block",
							children: hint
						}),
						/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
							className: cn("ml-auto rounded-full px-2 py-1 text-xs", mode === "play" ? "bg-accent text-accent-ink" : "bg-surface-3 text-muted"),
							children: paused ? "Paused" : mode === "play" ? "Playing" : "Selecting"
						})
					]
				}),
				sheet && /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
					className: "fixed inset-0 z-40 lg:hidden",
					children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
						type: "button",
						className: "absolute inset-0 bg-bg/70",
						"aria-label": "Close panel",
						onClick: () => setSheet(null)
					}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
						className: "scroll-thin absolute inset-x-0 bottom-12 max-h-[72dvh] overflow-y-auto rounded-t-xl border border-border bg-surface p-3",
						children: sheet === "tools" ? toolsPane : physicsPane
					})]
				}),
				confirmReset && /* @__PURE__ */ (0, import_jsx_runtime.jsx)("div", {
					className: "fixed inset-0 z-50 flex items-center justify-center bg-bg/75 p-4",
					children: /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
						className: "w-full max-w-sm rounded-xl border border-border bg-surface p-5",
						children: [
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("h2", {
								className: "text-lg font-semibold",
								children: "Reset the canvas?"
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsx)("p", {
								className: "mt-1 text-sm text-muted",
								children: "Clears the image, masks, and motion. Saved presets stay on this device."
							}),
							/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("div", {
								className: "mt-4 flex justify-end gap-2",
								children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-10 rounded-md px-3 text-sm",
									onClick: () => setConfirmReset(false),
									children: "Cancel"
								}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
									type: "button",
									className: "h-10 rounded-md bg-danger px-3 text-sm font-medium text-fg",
									onClick: () => void doReset(),
									children: "Reset"
								})]
							})
						]
					})
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: fileRef,
					type: "file",
					accept: "image/png,image/jpeg,image/webp,.png,.jpg,.jpeg,.webp",
					className: "hidden",
					onChange: (event) => {
						const file = event.target.files?.[0];
						event.target.value = "";
						if (file) openFile(file);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)("input", {
					ref: projectRef,
					type: "file",
					accept: "application/json,.json",
					className: "hidden",
					onChange: (event) => {
						const file = event.target.files?.[0];
						event.target.value = "";
						if (file) openProjectFile(file);
					}
				}),
				/* @__PURE__ */ (0, import_jsx_runtime.jsx)(Toaster, {
					theme: "dark",
					position: "top-center"
				})
			]
		})
	});
}
function IconButton({ label, onClick, disabled, pressed, children }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Tooltip, { children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipTrigger, {
		asChild: true,
		children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)("button", {
			type: "button",
			"aria-label": label,
			title: label,
			disabled,
			"aria-pressed": pressed,
			onClick,
			className: cn("inline-flex size-11 items-center justify-center rounded-md text-fg hover:bg-surface-3 disabled:opacity-35", pressed && "bg-surface-3 text-accent"),
			children
		})
	}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipPortal, { children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(TooltipContent, {
		className: "z-50 rounded-md bg-fg px-2 py-1 text-xs text-bg",
		sideOffset: 6,
		children: label
	}) })] });
}
function ToolButton({ icon, label, shortcut, active, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		title: `${label} (${shortcut})`,
		"aria-pressed": active,
		onClick,
		className: cn("flex h-11 items-center gap-2 rounded-md px-2 text-left text-sm", active ? "bg-accent text-accent-ink" : "bg-surface-2 text-fg hover:bg-surface-3"),
		children: [icon, /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
			className: "truncate",
			children: label
		})]
	});
}
function Field({ label, value, min = 0, max = 100, onChange }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("label", {
		className: "flex flex-col gap-1",
		children: [/* @__PURE__ */ (0, import_jsx_runtime.jsxs)("span", {
			className: "flex items-center justify-between text-xs text-muted",
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", { children: label }), /* @__PURE__ */ (0, import_jsx_runtime.jsx)("span", {
				className: "tabular-nums text-fg",
				children: Math.round(value)
			})]
		}), /* @__PURE__ */ (0, import_jsx_runtime.jsxs)(Slider, {
			className: "relative flex h-8 w-full touch-none items-center select-none",
			min,
			max,
			step: 1,
			value: [value],
			onValueChange: (values) => onChange(values[0] ?? value),
			children: [/* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderTrack, {
				className: "relative h-1.5 grow rounded-full bg-surface-3",
				children: /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderRange, { className: "absolute h-full rounded-full bg-accent" })
			}), /* @__PURE__ */ (0, import_jsx_runtime.jsx)(SliderThumb, {
				className: "block size-4 rounded-full border-2 border-accent bg-fg outline-none",
				"aria-label": label
			})]
		})]
	});
}
function MenuItem({ icon, label, onClick }) {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsxs)("button", {
		type: "button",
		className: "flex h-10 w-full items-center gap-2 rounded-md px-2 text-left text-sm hover:bg-surface-3",
		onClick,
		children: [icon, label]
	});
}
function Home() {
	return /* @__PURE__ */ (0, import_jsx_runtime.jsx)(Editor, {});
}
//#endregion
export { Home as component };
